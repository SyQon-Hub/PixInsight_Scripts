#feature-id SyQonStarless : SyQon > Starless
#feature-icon  syqonstarless.svg
#feature-info This script integrates with the SyQon Starless application to remove stars from images.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>

/****************************************************************************
 * ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗
 * ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║
 * ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║
 * ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║
 * ███████║   ██║   ╚██████╔╝╚█████╔╝ ██║ ╚████║
 * ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝
 *      ★  S T A R L E S S  ★
 *
 * SyQon Starless PixInsight Integration (SpiderMonkey / PI <= 1.9.3)
 * Version: v3.0.2
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * Integrates with SyQon Starless (Qt6/C++ build, Axiom V3 ONNX model).
 * Saves the current image as a temporary FITS file, launches SyQonStarless
 * with --gui so the user can control stretch settings interactively, then
 * imports the starless result back into PixInsight once the window closes.
 *
 * License context: "pixinsight" (requires a SyQon PixInsight license).
 *
 ******************************************************************************/

#define VERSION "v3.0.2"

// ============================================================================
// Platform helpers
// ============================================================================

var IS_WINDOWS = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows");
var IS_MACOS   = (CoreApplication.platform == "MACOSX"   || CoreApplication.platform == "macOS");
var IS_LINUX   = (CoreApplication.platform == "Linux");

if (!IS_WINDOWS && !IS_MACOS && !IS_LINUX)
   Console.criticalln("Unsupported platform: " + CoreApplication.platform);

var pathSeparator = IS_WINDOWS ? "\\" : "/";

// ============================================================================
// Temp / config paths
// ============================================================================

var scriptTempDir           = File.systemTempDirectory + pathSeparator + "SyQonStarlessCLI";
var syqonStarlessConfigFile = scriptTempDir + pathSeparator + "syqon_starless_config.csv";

if (!File.directoryExists(scriptTempDir))
   File.createDirectory(scriptTempDir);

// ============================================================================
// Parameters
// ============================================================================

var SyQonStarlessParameters = {
   targetView:            undefined,
   targetViewId:          "",
   starlessExePath:       "",
   overlap:               64,
   starsOnlyMode:         "Unscreen",
   outputTimeoutMinutes:  20,
   openDialogBox:         true,

   save: function() {
      Parameters.set("targetViewId",          this.targetViewId);
      Parameters.set("starlessExePath",       this.starlessExePath);
      Parameters.set("overlap",               this.overlap);
      Parameters.set("starsOnlyMode",         this.starsOnlyMode);
      Parameters.set("outputTimeoutMinutes",  this.outputTimeoutMinutes);
      Parameters.set("openDialogBox",         this.openDialogBox);
      this.savePathToFile();
   },

   load: function() {
      if (Parameters.has("targetViewId"))          this.targetViewId        = Parameters.getString("targetViewId");
      if (Parameters.has("starlessExePath"))       this.starlessExePath     = Parameters.getString("starlessExePath");
      if (Parameters.has("overlap"))               this.overlap             = Parameters.getInteger("overlap");
      if (Parameters.has("starsOnlyMode"))         this.starsOnlyMode       = Parameters.getString("starsOnlyMode");
      if (Parameters.has("outputTimeoutMinutes"))  this.outputTimeoutMinutes = Parameters.getInteger("outputTimeoutMinutes");
      if (Parameters.has("openDialogBox"))         this.openDialogBox       = Parameters.getBoolean("openDialogBox");

      this.loadPathFromFile();

      this.targetView = undefined;
      if (this.targetViewId && this.targetViewId.length > 0) {
         var w = ImageWindow.windowById(this.targetViewId);
         if (w && !w.isNull) this.targetView = w.mainView;
      }

      if (Parameters.isViewTarget && Parameters.targetView) {
         this.targetView   = Parameters.targetView;
         this.targetViewId = Parameters.targetView.id;
      }
   },

   savePathToFile: function() {
      try {
         var file = new File;
         file.createForWriting(syqonStarlessConfigFile);
         file.outTextLn(this.starlessExePath);
         file.close();
      } catch (error) {
         Console.warningln("Failed to save Starless executable path: " + error.message);
      }
   },

   loadPathFromFile: function() {
      // On macOS the install path is always fixed -- no need for the
      // user to browse for it.
      if (IS_MACOS) {
         this.starlessExePath = "/Applications/SyQonStarless.app/Contents/MacOS/SyQonStarless";
         return;
      }
      try {
         if (File.exists(syqonStarlessConfigFile)) {
            var lines = File.readLines(syqonStarlessConfigFile);
            if (lines.length > 0 && (!this.starlessExePath || this.starlessExePath.length == 0))
               this.starlessExePath = lines[0].trim();
         }
      } catch (error) {
         Console.warningln("Failed to load Starless executable path: " + error.message);
      }
      // Windows failsafe: standard installer location when we still have no path.
      if (IS_WINDOWS && (!this.starlessExePath || this.starlessExePath.length == 0)) {
         var defaultWinPath = "C:\\Program Files\\SyQon\\Starless\\SyQonStarless.exe";
         if (File.exists(defaultWinPath))
            this.starlessExePath = defaultWinPath;
      }
   }
};

// ============================================================================
// Utility helpers
// ============================================================================

function resolveWindowFromViewId(viewId) {
   if (!viewId || viewId.length == 0) return null;
   var w = ImageWindow.windowById(viewId);
   return (w && !w.isNull) ? w : null;
}

function getSelectedWindowFromDialog(dialog) {
   if (!dialog) return null;
   var idx = dialog.imageSelectionDropdown.currentItem;
   if (idx < 0 || idx >= dialog._windowIds.length) return null;
   return resolveWindowFromViewId(dialog._windowIds[idx]);
}

function validateStarlessExecutable(exePath) {
   return exePath && exePath.length > 0 && File.exists(exePath);
}

function sanitizeFileName(name) {
   return name.replace(/[^A-Za-z0-9_\-]/g, "_");
}

function deleteFileIfExists(filePath) {
   try {
      if (File.exists(filePath)) {
         File.remove(filePath);
         Console.writeln("Deleted file: " + filePath);
      }
   } catch (error) {
      Console.warningln("Failed to delete file: " + filePath + " -> " + error.message);
   }
}

function getActiveWindowIdSafe() {
   try   { return ImageWindow.activeWindow.mainView.id; }
   catch (e) { return ""; }
}

function ensureTempDirExists() {
   if (!File.directoryExists(scriptTempDir))
      File.createDirectory(scriptTempDir);
}

function buildRunPaths(baseName) {
   ensureTempDirExists();
   var runTag   = String((new Date()).getTime());
   var safeBase = sanitizeFileName(baseName);
   return {
      inputFilePath:  scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_input.tif",
      outputFilePath: scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_starless.tif",
      starsFilePath:  scriptTempDir + pathSeparator + "starmask_" + safeBase + "_" + runTag + "_starless.tif"
   };
}

function makeUniqueViewId(baseId) {
   return sanitizeFileName(baseId) + "_" + String((new Date()).getTime());
}

function formatElapsed(ms) {
   var s = Math.max(0, Math.floor(ms / 1000));
   var h = Math.floor(s / 3600); s -= h * 3600;
   var m = Math.floor(s / 60);   s -= m * 60;
   if (h > 0) return format("%d:%02d:%02d", h, m, s);
   return format("%02d:%02d", m, s);
}

// ============================================================================
// Clone / FITS helpers
// ============================================================================

function cloneWindowForProcessing(sourceWindow, newId) {
   var src = sourceWindow.mainView.image;
   var w = new ImageWindow(
      src.width, src.height,
      src.numberOfChannels, src.bitsPerSample,
      src.sampleType == SampleType_Real,
      src.isColor, newId
   );
   w.mainView.beginProcess(UndoFlag_NoSwapFile);
   w.mainView.image.assign(src);
   w.mainView.endProcess();
   return w;
}

function saveImageAsTiff(filePath, view) {
   var F = new FileFormat("TIFF", false, true);
   if (F.isNull)
      throw new Error("TIFF file format not available.");

   var f = new FileFormatInstance(F);
   if (f.isNull)
      throw new Error("Unable to create FileFormatInstance for TIFF.");

   var description = new ImageDescription();
   description.bitsPerSample      = 32;
   description.ieeefpSampleFormat = true;

   if (!f.create(filePath, "compression=none"))
      throw new Error("Unable to create TIFF file: " + filePath);

   if (!f.setOptions(description)) {
      f.close();
      throw new Error("Unable to set 32-bit float options for TIFF.");
   }

   if (!f.writeImage(view.image)) {
      f.close();
      throw new Error("Failed to write image to TIFF: " + filePath);
   }

   f.close();
   Console.writeln("Image saved as 32-bit float TIFF: " + filePath);
   return filePath;
}

function openImageFile(filePath, label) {
   if (!File.exists(filePath))
      throw new Error(label + " file not found: " + filePath);
   var opened = ImageWindow.open(filePath);
   if (!opened || opened.length < 1)
      throw new Error("Failed to open " + label + " image: " + filePath);
   var w = opened[0];
   w.show();
   return w;
}

// ============================================================================
// Output processing
// ============================================================================

function createStarsOnlyImage(originalWindow, starlessWindow, mode) {
   if (mode == "None") return;

   var originalId = originalWindow.mainView.id;
   var starlessId = starlessWindow.mainView.id;

   var P = new PixelMath;
   P.expression = (mode == "Subtraction")
      ? "(" + originalId + "-" + starlessId + ")"
      : "(" + originalId + "-" + starlessId + ")/(1-" + starlessId + ")";
   P.expression1              = "";
   P.expression2              = "";
   P.expression3              = "";
   P.useSingleExpression      = true;
   P.symbols                  = "";
   P.clearImageCacheAndExit   = false;
   P.cacheGeneratedImages     = false;
   P.generateOutput           = true;
   P.singleThreaded           = false;
   P.optimization             = true;
   P.use64BitWorkingImage     = false;
   P.rescale                  = false;
   P.truncate                 = true;
   P.truncateLower            = 0;
   P.truncateUpper            = 1;
   P.createNewImage           = true;
   P.showNewImage             = true;
   P.newImageId               = originalId + "_StarsOnly";
   P.newImageColorSpace       = PixelMath.prototype.SameAsTarget;
   P.newImageSampleFormat     = PixelMath.prototype.SameAsTarget;
   P.executeOn(originalWindow.mainView);
}

function overwriteTargetWithStarless(targetWindow, starlessWindow) {
   var starlessId = starlessWindow.mainView.id;
   if (!targetWindow.mainView.image.isColor && starlessWindow.mainView.image.isColor)
      starlessId = starlessId + "[0]";

   var pm = new PixelMath;
   pm.useSingleExpression = true;
   pm.expression          = starlessId;
   pm.createNewImage      = false;
   pm.rescale             = false;
   pm.truncate            = false;
   pm.executeOn(targetWindow.mainView);
}

function processStarlessOutput(outputFilePath, targetWindow, starsOnlyMode) {
   var starlessWindow = openImageFile(outputFilePath, "Starless");
   try {
      if (starsOnlyMode != "None")
         createStarsOnlyImage(targetWindow, starlessWindow, starsOnlyMode);
      overwriteTargetWithStarless(targetWindow, starlessWindow);
   } finally {
      starlessWindow.forceClose();
      deleteFileIfExists(outputFilePath);
   }
}

// ============================================================================
// CLI argument construction
// ============================================================================

function buildStarlessArgs(inputFilePath, outputFilePath) {
   // Real SyQonStarless.exe CLI contract (Qt6/C++ Axiom V3 build).
   // --gui opens the SyQonStarless window so the user controls stretch
   // settings interactively. PI polls for the output file after the
   // process exits (processExited flag gates the import).
   var args = [];
   args.push("-i"); args.push(inputFilePath);
   args.push("-o"); args.push(outputFilePath);
   args.push("-v"); args.push(String(SyQonStarlessParameters.overlap));
   args.push("-c"); args.push("pixinsight");
   args.push("--gui");
   return args;
}

// ============================================================================
// executeStarlessOnWindow
// ============================================================================

function executeStarlessOnWindow(targetWindow) {
   var tempInputFilePath  = "";
   var tempOutputFilePath = "";
   var tempCloneWindow    = null;

   try {
      if (!targetWindow || targetWindow.isNull)
         throw new Error("No valid target image selected.");
      if (!validateStarlessExecutable(SyQonStarlessParameters.starlessExePath))
         throw new Error("SyQon Starless executable not found. Please select it with the wrench button.");

      // Resolve macOS .app bundles to the actual binary inside them.
      var resolvedExePath = SyQonStarlessParameters.starlessExePath;

      SyQonStarlessParameters.targetView   = targetWindow.mainView;

      SyQonStarlessParameters.targetView   = targetWindow.mainView;
      SyQonStarlessParameters.targetViewId = targetWindow.mainView.id;
      SyQonStarlessParameters.save();

      var runPaths = buildRunPaths(targetWindow.mainView.id);
      tempInputFilePath  = runPaths.inputFilePath;
      tempOutputFilePath = runPaths.outputFilePath;

      var cloneId = makeUniqueViewId(targetWindow.mainView.id + "_StarlessTemp");
      tempCloneWindow = cloneWindowForProcessing(targetWindow, cloneId);
      saveImageAsTiff(tempInputFilePath, tempCloneWindow.mainView);
      tempCloneWindow.forceClose();
      tempCloneWindow = null;

      var args = buildStarlessArgs(tempInputFilePath, tempOutputFilePath);

      var controller = new StarlessRunController(targetWindow, runPaths);
      tempInputFilePath  = "";
      tempOutputFilePath = "";

      controller.start(resolvedExePath, args);

   } catch (error) {
      Console.criticalln("SyQon Starless failed: " + error.message);
   } finally {
      if (tempCloneWindow && !tempCloneWindow.isNull)
         try { tempCloneWindow.forceClose(); } catch (e) {}
      if (tempInputFilePath.length  > 0) deleteFileIfExists(tempInputFilePath);
      if (tempOutputFilePath.length > 0) deleteFileIfExists(tempOutputFilePath);
   }
}

// ============================================================================
// StarlessRunController
// ============================================================================

function StarlessRunController(targetWindow, runPaths) {
   this.targetWindow  = targetWindow;
   this.runPaths      = runPaths;
   this.process       = new ExternalProcess;
   this.waitDialog    = null;
   this.timer         = null;
   this.startTime     = 0;
   this.timeoutMs     = Math.max(1, SyQonStarlessParameters.outputTimeoutMinutes || 20) * 60 * 1000;
   this.canceled      = false;
   this.completed     = false;
   this.cleaned       = false;
   this.processExited = false;
   this.stdoutBuffer  = "";
   this.stderrBuffer  = "";
   this.lastStage     = "Waiting for SyQon Starless window to close...";
   this.lastPercent   = -1;
}

StarlessRunController.prototype.cleanupOnSuccess = function() {
   if (this.cleaned) return;
   this.cleaned = true;
   deleteFileIfExists(this.runPaths.inputFilePath);
   deleteFileIfExists(this.runPaths.starsFilePath);
   // outputFilePath deleted inside processStarlessOutput after load
};

StarlessRunController.prototype.cleanupOnCancel = function() {
   if (this.cleaned) return;
   this.cleaned = true;
   deleteFileIfExists(this.runPaths.inputFilePath);
};

StarlessRunController.prototype.handleLine = function(line) {
   if (!line) return;
   var text = line.trim();
   if (text.length == 0) return;

   // Parse [CLI] Progress: XX% lines
   var pctMatch = text.match(/\[CLI\]\s+Progress:\s*(\d+)%/i);
   if (pctMatch) {
      this.lastPercent = parseInt(pctMatch[1], 10);
      this.lastStage   = "Processing tiles...";
      if (this.waitDialog)
         this.waitDialog.updateStatus(this.lastStage, this.lastPercent, this.startTime, this.timeoutMs);
      return;
   }

   // Parse [CLI] Status: ... stage lines
   var stageMatch = text.match(/\[CLI\]\s+Status:\s*(.+)/i);
   if (stageMatch) {
      this.lastStage = stageMatch[1].trim();
      if (this.waitDialog)
         this.waitDialog.updateStatus(this.lastStage, this.lastPercent, this.startTime, this.timeoutMs);
      Console.noteln(text);
      return;
   }

   Console.noteln(text);
};

StarlessRunController.prototype.processBufferedText = function(chunk, which) {
   if (!chunk || chunk.length == 0) return;
   if (which == "stdout") this.stdoutBuffer += chunk;
   else                   this.stderrBuffer += chunk;

   var buffer    = (which == "stdout") ? this.stdoutBuffer : this.stderrBuffer;
   var lines     = buffer.split(/\r?\n/);
   var remainder = lines.pop();

   for (var i = 0; i < lines.length; ++i)
      if (which == "stdout") this.handleLine(lines[i]);

   if (which == "stdout") this.stdoutBuffer = remainder;
   else                   this.stderrBuffer = remainder;
};

StarlessRunController.prototype.start = function(exePath, args) {
   var self = this;

   this.process.onStandardOutputDataAvailable = function() {
      self.processBufferedText(String(this.stdout), "stdout");
   };

   this.process.onStandardErrorDataAvailable = function() {
      self.processBufferedText(String(this.stderr), "stderr");
   };

   this.process.onStarted = function() {
      Console.noteln("SyQon Starless launched.");
      Console.noteln("Executable: " + exePath);
      Console.noteln("Arguments: " + args.join(" "));
      self.lastStage = "SyQon Starless window open -- process your image and click Generate Starless.";
      if (self.waitDialog)
         self.waitDialog.updateStatus(self.lastStage, -1, self.startTime, self.timeoutMs);
   };

   this.process.onFinished = function() {
      if (self.stdoutBuffer.length > 0) { self.handleLine(self.stdoutBuffer); self.stdoutBuffer = ""; }
      self.processExited = true;
      Console.noteln("SyQon Starless window closed.");
      self.lastStage = "Window closed -- loading output...";
      if (self.waitDialog)
         self.waitDialog.updateStatus(self.lastStage, 99, self.startTime, self.timeoutMs);
   };

   this.process.onError = function(code) {
      Console.warningln("ExternalProcess reported: " + code);
   };

   this.startTime  = (new Date()).getTime();
   this.waitDialog = new StarlessWaitDialog(this);
   this.waitDialog.updateStatus("Launching SyQon Starless...", -1, this.startTime, this.timeoutMs);

   try { this.process.start(exePath, args); }
   catch (e) { throw new Error("Failed to start SyQon Starless: " + e.message); }

   this.startTimer();
   this.waitDialog.execute();
};

StarlessRunController.prototype.startTimer = function() {
   var self = this;
   this.timer          = new Timer;
   this.timer.interval = 0.5;
   this.timer.periodic = true;
   this.timer.onTimeout = function() { self.poll(); };
   this.timer.start();
};

StarlessRunController.prototype.stopTimer = function() {
   try { if (this.timer) this.timer.stop(); } catch (e) {}
};

StarlessRunController.prototype.poll = function() {
   if (this.canceled || this.completed) return;

   var now     = (new Date()).getTime();
   var elapsed = now - this.startTime;

   if (this.waitDialog)
      this.waitDialog.updateStatus(this.lastStage, this.lastPercent, this.startTime, this.timeoutMs);

   // Only import after the SyQon process has actually exited AND the
   // output file exists -- prevents PI grabbing the file mid-write
   // while the user is still reviewing inside the SyQon window.
   if (this.processExited && File.exists(this.runPaths.outputFilePath)) {
      this.completed = true;
      this.stopTimer();

      var maxRetries = 10;
      var retryDelay = 2000;
      var lastError  = "";
      var succeeded  = false;

      for (var attempt = 0; attempt < maxRetries; ++attempt) {
         try { msleep(retryDelay); } catch (e) {}
         try {
            processStarlessOutput(
               this.runPaths.outputFilePath,
               this.targetWindow,
               SyQonStarlessParameters.starsOnlyMode
            );
            succeeded = true;
            break;
         } catch (e) {
            lastError = e.message;
            Console.warningln("Output not ready yet (attempt " + (attempt+1) + "/" + maxRetries + "): " + lastError);
         }
      }

      if (succeeded)
         Console.writeln("Starless processing complete on: " + this.targetWindow.mainView.id);
      else
         Console.criticalln("SyQon Starless failed while importing output: " + lastError);

      this.cleanupOnSuccess();
      if (this.waitDialog) this.waitDialog.ok();
      return;
   }

   // If process exited but no output -- user cancelled without processing
   if (this.processExited) {
      this.completed = true;
      this.stopTimer();
      this.cleanupOnCancel();
      if (this.waitDialog) this.waitDialog.cancel();
      Console.warningln("SyQon Starless closed without producing output (cancelled or not processed).");
      return;
   }

   // Timeout guard
   if (elapsed >= this.timeoutMs) {
      this.completed = true;
      this.stopTimer();
      this.cleanupOnCancel();
      if (this.waitDialog) this.waitDialog.cancel();
      Console.criticalln("SyQon Starless timed out -- output file was not produced before timeout.");
      return;
   }
};

StarlessRunController.prototype.cancelWaiting = function() {
   if (this.completed || this.canceled) return;
   this.canceled = true;
   this.stopTimer();
   this.cleanupOnCancel();
   try {
      if (this.process && this.process.isRunning)
         this.process.terminate();
   } catch (e) {}
   Console.warningln("Cancelled -- SyQon Starless terminated.");
   if (this.waitDialog) this.waitDialog.cancel();
};

// ============================================================================
// StarlessWaitDialog
// ============================================================================

function StarlessWaitDialog(controller) {
   this.__base__ = Dialog;
   this.__base__();

   var self = this;
   this.controller    = controller;
   this.windowTitle   = "SyQon Starless \u2014 Waiting";
   this.userResizable = false;
   this.minWidth      = 560;

   this.waitHeaderLabel = new Label(this);
   this.waitHeaderLabel.useRichText    = true;
   this.waitHeaderLabel.textAlignment  = TextAlign_Center;
   this.waitHeaderLabel.text =
      "<b><font size='+1'>\u2605 SyQon Starless \u2605</font></b><br/>" +
      "<font size='-1'>Waiting for processing to complete...</font>";

   this.headerSep = new Frame(this);
   this.headerSep.frameStyle = FrameStyle_Box;
   this.headerSep.setFixedHeight(2);

   this.statusGroup       = new GroupBox(this);
   this.statusGroup.title = "Status";

   this.infoLabel = new Label(this);
   this.infoLabel.useRichText  = true;
   this.infoLabel.wordWrapping = true;
   this.infoLabel.text         = "<i>SyQon Starless window is open. Adjust settings and click Generate Starless, then close the window.</i>";

   this.progressLabel = new Label(this);
   this.progressLabel.useRichText = true;
   this.progressLabel.text        = "<b>Progress:</b> starting...";

   this.progressBarLabel = new Label(this);
   this.progressBarLabel.useRichText = false;
   this.progressBarLabel.text        = "";

   this.elapsedLabel = new Label(this);
   this.elapsedLabel.useRichText = true;
   this.elapsedLabel.text        = "<b>Elapsed:</b> 00:00";

   this.statusGroup.sizer = new VerticalSizer;
   this.statusGroup.sizer.margin  = 8;
   this.statusGroup.sizer.spacing = 6;
   this.statusGroup.sizer.add(this.infoLabel);
   this.statusGroup.sizer.add(this.progressLabel);
   this.statusGroup.sizer.add(this.progressBarLabel);
   this.statusGroup.sizer.add(this.elapsedLabel);

   this.noteLabel = new Label(this);
   this.noteLabel.useRichText  = true;
   this.noteLabel.wordWrapping = true;
   this.noteLabel.text =
      "<i>The SyQon Starless window is running as a separate application.<br/>" +
      "Process your image there, then close that window.<br/>" +
      "Clicking Cancel here will terminate SyQon Starless immediately.</i>";

   this.cancelButton = new PushButton(this);
   this.cancelButton.text = "Cancel";
   this.cancelButton.onClick = function() { self.controller.cancelWaiting(); };

   this.buttonSizer = new HorizontalSizer;
   this.buttonSizer.addStretch();
   this.buttonSizer.add(this.cancelButton);
   this.buttonSizer.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.margin  = 12;
   this.sizer.spacing = 8;
   this.sizer.add(this.waitHeaderLabel);
   this.sizer.add(this.headerSep);
   this.sizer.addSpacing(4);
   this.sizer.add(this.statusGroup);
   this.sizer.addSpacing(4);
   this.sizer.add(this.noteLabel);
   this.sizer.addSpacing(8);
   this.sizer.add(this.buttonSizer);

   this.adjustToContents();
}
StarlessWaitDialog.prototype = new Dialog;

StarlessWaitDialog.prototype.updateStatus = function(stage, percent, startTime, timeoutMs) {
   var now     = (new Date()).getTime();
   var elapsed = now - startTime;
   var remain  = Math.max(0, timeoutMs - elapsed);

   this.progressLabel.text = (percent >= 0)
      ? ("<b>Progress:</b> " + stage + "  [<b>" + percent + "%</b>]")
      : ("<b>Progress:</b> " + stage);

   if (percent >= 0) {
      var barLen = 40;
      var filled = Math.round(barLen * percent / 100);
      var bar    = "";
      for (var i = 0; i < barLen; i++)
         bar += (i < filled) ? "\u2588" : "\u2591";
      this.progressBarLabel.text = bar + "  " + percent + "%";
   } else {
      this.progressBarLabel.text = "";
   }

   this.elapsedLabel.text =
      "<b>Elapsed:</b> " + formatElapsed(elapsed) +
      "    <b>Timeout in:</b> " + formatElapsed(remain);
};

// ============================================================================
// SyQonStarlessDialog
// ============================================================================

function SyQonStarlessDialog() {
   this.__base__ = Dialog;
   this.__base__();

   var self = this;

   SyQonStarlessParameters.load();
   this._windowIds = [];

   this.syncToParameters = function() {
      SyQonStarlessParameters.overlap              = this.overlapSpin.value;
      SyQonStarlessParameters.starsOnlyMode        = this.starsOnlyModeCombo.itemText(this.starsOnlyModeCombo.currentItem);
      SyQonStarlessParameters.outputTimeoutMinutes = this.outputTimeoutSpin.value;
      SyQonStarlessParameters.openDialogBox        = this.openDialogCheckbox.checked;

      var w = getSelectedWindowFromDialog(this);
      if (w && !w.isNull) {
         SyQonStarlessParameters.targetView   = w.mainView;
         SyQonStarlessParameters.targetViewId = w.mainView.id;
      }
      SyQonStarlessParameters.save();
   };

   this.selectViewById = function(viewId) {
      if (!viewId || viewId.length == 0) return false;
      for (var i = 0; i < this._windowIds.length; ++i)
         if (this._windowIds[i] == viewId) {
            this.imageSelectionDropdown.currentItem = i;
            return true;
         }
      return false;
   };

   // ── Header ──
   this.headerLabel = new Label(this);
   this.headerLabel.useRichText   = true;
   this.headerLabel.textAlignment = TextAlign_Center;
   this.headerLabel.text =
      "<b><font size='+2'>\u2605 SyQon Starless \u2605</font></b><br/>" +
      "<font size='-1'>Axiom V3 \u2014 PixInsight Integration</font>";

   this.headerSeparator = new Frame(this);
   this.headerSeparator.frameStyle = FrameStyle_Box;
   this.headerSeparator.setFixedHeight(2);

   // ── Image selection ──
   this.imageSelectionLabel = new Label(this);
   this.imageSelectionLabel.text          = "Target Image:";
   this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.imageSelectionDropdown = new ComboBox(this);
   this.imageSelectionDropdown.editEnabled = false;

   var windows        = ImageWindow.windows;
   var activeWindowId = getActiveWindowIdSafe();
   for (var i = 0; i < windows.length; ++i) {
      var wid = windows[i].mainView.id;
      this.imageSelectionDropdown.addItem(wid);
      this._windowIds.push(wid);
      if (wid == activeWindowId)
         this.imageSelectionDropdown.currentItem = i;
   }

   this.imageSelectionSizer = new HorizontalSizer;
   this.imageSelectionSizer.spacing = 4;
   this.imageSelectionSizer.add(this.imageSelectionLabel);
   this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

   // ── Overlap ──
   this.overlapLabel = new Label(this);
   this.overlapLabel.text          = "Overlap:";
   this.overlapLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.overlapLabel.toolTip       =
      "Per-side Hann blend region in pixels (tile size fixed at 512).\n" +
      "64 = default (stride 384). 128 = large overlap (stride 256, ~2x tiles, better edges).";

   this.overlapSpin = new SpinBox(this);
   this.overlapSpin.minValue = 8;
   this.overlapSpin.maxValue = 255;
   this.overlapSpin.stepSize = 8;
   this.overlapSpin.value    = SyQonStarlessParameters.overlap;
   this.overlapSpin.onValueUpdated = function(value) { SyQonStarlessParameters.overlap = value; };

   this.overlapSizer = new HorizontalSizer;
   this.overlapSizer.spacing = 4;
   this.overlapSizer.add(this.overlapLabel);
   this.overlapSizer.add(this.overlapSpin);
   this.overlapSizer.addStretch();

   // ── Stars only mode ──
   this.starsOnlyModeLabel = new Label(this);
   this.starsOnlyModeLabel.text          = "Stars Only:";
   this.starsOnlyModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.starsOnlyModeCombo = new ComboBox(this);
   this.starsOnlyModeCombo.addItem("None");
   this.starsOnlyModeCombo.addItem("Subtraction");
   this.starsOnlyModeCombo.addItem("Unscreen");

   var somIndex = 2;
   if      (SyQonStarlessParameters.starsOnlyMode == "None")        somIndex = 0;
   else if (SyQonStarlessParameters.starsOnlyMode == "Subtraction") somIndex = 1;
   else if (SyQonStarlessParameters.starsOnlyMode == "Unscreen")    somIndex = 2;
   this.starsOnlyModeCombo.currentItem    = somIndex;
   SyQonStarlessParameters.starsOnlyMode  = this.starsOnlyModeCombo.itemText(somIndex);
   this.starsOnlyModeCombo.onItemSelected = function(index) {
      SyQonStarlessParameters.starsOnlyMode = this.itemText(index);
   };

   this.starsOnlyModeSizer = new HorizontalSizer;
   this.starsOnlyModeSizer.spacing = 4;
   this.starsOnlyModeSizer.add(this.starsOnlyModeLabel);
   this.starsOnlyModeSizer.add(this.starsOnlyModeCombo, 100);

   // ── Output timeout ──
   this.outputTimeoutLabel = new Label(this);
   this.outputTimeoutLabel.text          = "Output Timeout (min):";
   this.outputTimeoutLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.outputTimeoutLabel.toolTip       = "Maximum time to wait for the Starless output file before aborting.";

   this.outputTimeoutSpin = new SpinBox(this);
   this.outputTimeoutSpin.minValue = 1;
   this.outputTimeoutSpin.maxValue = 240;
   this.outputTimeoutSpin.stepSize = 1;
   this.outputTimeoutSpin.value    = SyQonStarlessParameters.outputTimeoutMinutes;
   this.outputTimeoutSpin.onValueUpdated = function(value) { SyQonStarlessParameters.outputTimeoutMinutes = value; };

   this.outputTimeoutSizer = new HorizontalSizer;
   this.outputTimeoutSizer.spacing = 4;
   this.outputTimeoutSizer.add(this.outputTimeoutLabel);
   this.outputTimeoutSizer.add(this.outputTimeoutSpin);
   this.outputTimeoutSizer.addStretch();

   // ── Open dialog checkbox ──
   this.openDialogCheckbox = new CheckBox(this);
   this.openDialogCheckbox.text    = "Open dialog when instance is double-clicked or dropped";
   this.openDialogCheckbox.checked = SyQonStarlessParameters.openDialogBox;
   this.openDialogCheckbox.onCheck = function(checked) { SyQonStarlessParameters.openDialogBox = checked; };

   // ── Executable ──
   this.setupButton = new ToolButton(this);
   this.setupButton.icon = this.scaledResource(":/icons/wrench.png");
   this.setupButton.setScaledFixedSize(24, 24);
   this.setupButton.toolTip = "Select the SyQonStarless executable file.";
   this.setupButton.onClick = function() {
      var ofd = new OpenFileDialog;
      ofd.caption            = "Select SyQonStarless Executable";
      ofd.multipleSelections = false;
      if (SyQonStarlessParameters.starlessExePath.length > 0)
         ofd.initialPath = SyQonStarlessParameters.starlessExePath;
      if (IS_WINDOWS)
         ofd.filters = [["Executable Files","*.exe"],["All Files","*"]];
      else
         ofd.filters = [["All Files","*"]];
      if (ofd.execute()) {
         var picked = "";
         if (ofd.fileNames && ofd.fileNames.length > 0)
            picked = String(ofd.fileNames[0]);
         else if (typeof ofd.filePath === "string")
            picked = ofd.filePath;

         if (picked.length > 0) {
            SyQonStarlessParameters.starlessExePath = picked;
            SyQonStarlessParameters.save();
            self.exePathLabel.text = picked;
         } else {
            Console.warningln("No file was returned from the selection dialog.");
         }
      }
   };

   this.exePathLabel = new TextBox(this);
   this.exePathLabel.readOnly    = true;
   this.exePathLabel.setFixedHeight(48);
   this.exePathLabel.text = (SyQonStarlessParameters.starlessExePath.length > 0)
      ? SyQonStarlessParameters.starlessExePath
      : "No SyQonStarless executable selected.";

   this.exePathSizer = new HorizontalSizer;
   this.exePathSizer.spacing = 6;
   this.exePathSizer.add(this.setupButton);
   this.exePathSizer.add(this.exePathLabel, 100);

   // ── Buttons ──
   this.okButton = new PushButton(this);
   this.okButton.text = "OK";
   this.okButton.onClick = function() { self.syncToParameters(); self.ok(); };

   this.cancelButton = new PushButton(this);
   this.cancelButton.text    = "Cancel";
   this.cancelButton.onClick = function() { self.cancel(); };

   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip      = "Drag to workspace to create a new process instance";
   this.newInstanceButton.onMousePress = function() { self.syncToParameters(); self.newInstance(); };

   this.buttonsSizer = new HorizontalSizer;
   this.buttonsSizer.spacing = 6;
   this.buttonsSizer.add(this.newInstanceButton);
   this.buttonsSizer.addStretch();
   this.buttonsSizer.add(this.okButton);
   this.buttonsSizer.add(this.cancelButton);

   // ── Label width alignment ──
   var labelWidth = this.font.width("Output Timeout (min):MMMM");
   this.imageSelectionLabel.setFixedWidth(labelWidth);
   this.overlapLabel.setFixedWidth(labelWidth);
   this.starsOnlyModeLabel.setFixedWidth(labelWidth);
   this.outputTimeoutLabel.setFixedWidth(labelWidth);

   // ── GroupBoxes ──
   this.imageGroup = new GroupBox(this);
   this.imageGroup.title = "Target Image";
   this.imageGroup.sizer = new VerticalSizer;
   this.imageGroup.sizer.margin = 6; this.imageGroup.sizer.spacing = 4;
   this.imageGroup.sizer.add(this.imageSelectionSizer);

   this.modelGroup = new GroupBox(this);
   this.modelGroup.title = "Model Settings (Axiom V3 \u2014 tile size fixed at 512)";
   this.modelGroup.sizer = new VerticalSizer;
   this.modelGroup.sizer.margin = 6; this.modelGroup.sizer.spacing = 4;
   this.modelGroup.sizer.add(this.overlapSizer);

   this.starlessGroup = new GroupBox(this);
   this.starlessGroup.title = "Starless Output";
   this.starlessGroup.sizer = new VerticalSizer;
   this.starlessGroup.sizer.margin = 6; this.starlessGroup.sizer.spacing = 4;
   this.starlessGroup.sizer.add(this.starsOnlyModeSizer);

   this.advancedGroup = new GroupBox(this);
   this.advancedGroup.title = "Advanced";
   this.advancedGroup.sizer = new VerticalSizer;
   this.advancedGroup.sizer.margin = 6; this.advancedGroup.sizer.spacing = 4;
   this.advancedGroup.sizer.add(this.outputTimeoutSizer);
   this.advancedGroup.sizer.add(this.openDialogCheckbox);

   this.executableGroup = new GroupBox(this);
   this.executableGroup.title = "SyQonStarless Executable";
   this.executableGroup.visible = !IS_MACOS;
   this.executableGroup.sizer = new VerticalSizer;
   this.executableGroup.sizer.margin = 6; this.executableGroup.sizer.spacing = 4;
   this.executableGroup.sizer.add(this.exePathSizer);

   this.infoLabel = new Label(this);
   this.infoLabel.useRichText  = true;
   this.infoLabel.wordWrapping = true;
   this.infoLabel.text =
      "<i>Stretch settings, device selection, and tile overlap are controlled inside " +
      "the SyQon Starless window. Click <b>Generate Starless</b> there, " +
      "then close the window to return the result to PixInsight.</i>";

   this.copyrightLabel = new Label(this);
   this.copyrightLabel.useRichText   = true;
   this.copyrightLabel.textAlignment = TextAlign_Center;
   this.copyrightLabel.text =
      "<font size='-1'>\u00A9 SyQon 2026 \u2014 www.syqon.it &nbsp;\u2014&nbsp; " +
      "Script by Franklin Marek \u2014 www.setiastro.com</font>";

   // ── Main sizer ──
   this.sizer = new VerticalSizer;
   this.sizer.margin  = 12;
   this.sizer.spacing = 8;
   this.sizer.add(this.headerLabel);
   this.sizer.add(this.headerSeparator);
   this.sizer.addSpacing(4);
   this.sizer.add(this.imageGroup);
   this.sizer.add(this.modelGroup);
   this.sizer.add(this.starlessGroup);
   this.sizer.add(this.advancedGroup);
   this.sizer.add(this.executableGroup);
   this.sizer.addSpacing(4);
   this.sizer.add(this.infoLabel);
   this.sizer.addSpacing(8);
   this.sizer.add(this.buttonsSizer);
   this.sizer.addSpacing(2);
   this.sizer.add(this.copyrightLabel);

   this.windowTitle = "SyQon Starless " + VERSION;
   this.setMinWidth(560);
   this.adjustToContents();

   if (SyQonStarlessParameters.targetViewId && SyQonStarlessParameters.targetViewId.length > 0)
      this.selectViewById(SyQonStarlessParameters.targetViewId);
}
SyQonStarlessDialog.prototype = new Dialog;

// ============================================================================
// Main
// ============================================================================

function main() {
   console.show();
   Console.criticalln(" ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗");
   Console.criticalln(" ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║");
   Console.criticalln(" ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║");
   Console.warningln( " ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║");
   Console.warningln( " ███████║   ██║   ╚██████╔╝╚█████╔╝ ██║ ╚████║");
   Console.warningln( " ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝");
   Console.noteln("SyQon \u2605 S T A R L E S S \u2605  " + VERSION);
   Console.noteln("\u00A9 SyQon 2026 \u2014 www.syqon.it");
   Console.noteln("Script by Franklin Marek \u2014 www.setiastro.com");
   console.flush();

   SyQonStarlessParameters.load();

   if (Parameters.isGlobalTarget) {
      Console.criticalln("This script cannot run in a global context.");
      return;
   }

   if (Parameters.isViewTarget && Parameters.targetView) {
      SyQonStarlessParameters.targetView   = Parameters.targetView;
      SyQonStarlessParameters.targetViewId = Parameters.targetView.id;
      SyQonStarlessParameters.save();

      if (SyQonStarlessParameters.openDialogBox) {
         var dlg = new SyQonStarlessDialog();
         dlg.selectViewById(SyQonStarlessParameters.targetViewId);
         if (dlg.execute()) {
            var selectedWindow = getSelectedWindowFromDialog(dlg)
               || resolveWindowFromViewId(SyQonStarlessParameters.targetViewId);
            executeStarlessOnWindow(selectedWindow);
         } else {
            Console.noteln("SyQon Starless dialog closed.");
         }
         return;
      }

      executeStarlessOnWindow(Parameters.targetView.window);
      return;
   }

   var dlg = new SyQonStarlessDialog();
   if (dlg.execute()) {
      var selectedWindow = getSelectedWindowFromDialog(dlg);
      if (!selectedWindow && SyQonStarlessParameters.targetViewId.length > 0)
         selectedWindow = resolveWindowFromViewId(SyQonStarlessParameters.targetViewId);
      if (!selectedWindow)
         throw new Error("Please select an image.");
      executeStarlessOnWindow(selectedWindow);
   } else {
      Console.noteln("SyQon Starless dialog closed.");
   }
}

main();
