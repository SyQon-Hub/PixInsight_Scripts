#feature-id SyQonStarless : SyQon > Starless
#feature-icon  syqonstarless.svg
#feature-info This script integrates with the SyQon Starless CLI application to remove stars from images.

/****************************************************************************
 * ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗
 * ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║
 * ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║
 * ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║
 * ███████║   ██║   ╚██████╔╝╚█████╔╝ ██║ ╚████║
 * ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝
 *      ★  S T A R L E S S  ★
 *
 * SyQon Starless CLI PixInsight Integration
 * Version: v2.1
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script integrates with the SyQon Starless CLI application (Axiom V2.1).
 * It saves the current image as a temporary FITS file, runs starless_cli
 * headlessly with the selected options, and then imports the starless
 * result back into the target image.
 *
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>

#define VERSION "v2.0"

// ----------------------------------------------------------------------------
// Platform helpers
// ----------------------------------------------------------------------------

let IS_WINDOWS = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows");
let IS_MACOS   = (CoreApplication.platform == "MACOSX"   || CoreApplication.platform == "macOS");
let IS_LINUX   = (CoreApplication.platform == "Linux");

if (!IS_WINDOWS && !IS_MACOS && !IS_LINUX)
   console.criticalln("Unsupported platform: " + CoreApplication.platform);

let pathSeparator = IS_WINDOWS ? "\\" : "/";

// ----------------------------------------------------------------------------
// Temp/config paths
// ----------------------------------------------------------------------------

let scriptTempDir       = File.systemTempDirectory + pathSeparator + "SyQonStarlessCLI";
let syqonStarlessConfigFile = scriptTempDir + pathSeparator + "syqon_starless_config.csv";

if (!File.directoryExists(scriptTempDir))
   File.createDirectory(scriptTempDir);

// ----------------------------------------------------------------------------
// Parameters
// ----------------------------------------------------------------------------

var SyQonStarlessParameters = {
   targetView:            undefined,
   targetViewId:          "",
   starlessExePath:       "",
   tileSize:              512,
   overlap:               128,
   pad:                   512,
   useMTF:                true,
   mtfTarget:             0.15,
   useAMP:                false,
   ampDType:              "fp16",
   useCPU:                false,
   noDML:                 false,
   starsOnlyMode:         "Subtraction",   // None | Subtraction | Unscreen
   outputTimeoutMinutes:  20,
   openDialogBox:         true,

   save: function() {
      Parameters.set("targetViewId",           this.targetViewId);
      Parameters.set("starlessExePath",        this.starlessExePath);
      Parameters.set("tileSize",               this.tileSize);
      Parameters.set("overlap",                this.overlap);
      Parameters.set("pad",                    this.pad);
      Parameters.set("useMTF",                 this.useMTF);
      Parameters.set("mtfTarget",              this.mtfTarget);
      Parameters.set("useAMP",                 this.useAMP);
      Parameters.set("ampDType",               this.ampDType);
      Parameters.set("useCPU",                 this.useCPU);
      Parameters.set("noDML",                  this.noDML);
      Parameters.set("starsOnlyMode",          this.starsOnlyMode);
      Parameters.set("outputTimeoutMinutes",   this.outputTimeoutMinutes);
      Parameters.set("openDialogBox",          this.openDialogBox);
      this.savePathToFile();
   },

   load: function() {
      if (Parameters.has("targetViewId"))
         this.targetViewId = Parameters.getString("targetViewId");
      if (Parameters.has("starlessExePath"))
         this.starlessExePath = Parameters.getString("starlessExePath");
      if (Parameters.has("tileSize"))
         this.tileSize = Parameters.getInteger("tileSize");
      if (Parameters.has("overlap"))
         this.overlap = Parameters.getInteger("overlap");
      if (Parameters.has("pad"))
         this.pad = Parameters.getInteger("pad");
      if (Parameters.has("useMTF"))
         this.useMTF = Parameters.getBoolean("useMTF");
      if (Parameters.has("mtfTarget"))
         this.mtfTarget = Parameters.getReal("mtfTarget");
      if (Parameters.has("useAMP"))
         this.useAMP = Parameters.getBoolean("useAMP");
      if (Parameters.has("ampDType"))
         this.ampDType = Parameters.getString("ampDType");
      if (Parameters.has("useCPU"))
         this.useCPU = Parameters.getBoolean("useCPU");
      if (Parameters.has("noDML"))
         this.noDML = Parameters.getBoolean("noDML");
      if (Parameters.has("starsOnlyMode"))
         this.starsOnlyMode = Parameters.getString("starsOnlyMode");
      if (Parameters.has("outputTimeoutMinutes"))
         this.outputTimeoutMinutes = Parameters.getInteger("outputTimeoutMinutes");
      if (Parameters.has("openDialogBox"))
         this.openDialogBox = Parameters.getBoolean("openDialogBox");

      this.loadPathFromFile();

      this.targetView = undefined;
      if (this.targetViewId && this.targetViewId.length > 0) {
         let w = ImageWindow.windowById(this.targetViewId);
         if (w && !w.isNull)
            this.targetView = w.mainView;
      }

      if (Parameters.isViewTarget && Parameters.targetView) {
         this.targetView   = Parameters.targetView;
         this.targetViewId = Parameters.targetView.id;
      }
   },

   savePathToFile: function() {
      try {
         let file = new File;
         file.createForWriting(syqonStarlessConfigFile);
         file.outTextLn(this.starlessExePath);
         file.close();
      } catch (error) {
         console.warningln("Failed to save Starless executable path: " + error.message);
      }
   },

   loadPathFromFile: function() {
      try {
         if (File.exists(syqonStarlessConfigFile)) {
            let lines = File.readLines(syqonStarlessConfigFile);
            if (lines.length > 0 && (!this.starlessExePath || this.starlessExePath.length == 0))
               this.starlessExePath = lines[0].trim();
         }
      } catch (error) {
         console.warningln("Failed to load Starless executable path: " + error.message);
      }
   }
};

// ----------------------------------------------------------------------------
// Utility helpers
// ----------------------------------------------------------------------------

function resolveWindowFromViewId(viewId) {
   if (!viewId || viewId.length == 0)
      return null;
   let w = ImageWindow.windowById(viewId);
   if (w && !w.isNull)
      return w;
   return null;
}

function getSelectedWindowFromDialog(dialog) {
   if (!dialog)
      return null;
   let idx = dialog.imageSelectionDropdown.currentItem;
   if (idx < 0 || idx >= dialog._windowIds.length)
      return null;
   let id = dialog._windowIds[idx];
   return resolveWindowFromViewId(id);
}

function validateStarlessExecutable(exePath) {
   if (!exePath || exePath.length == 0)
      return false;
   return File.exists(exePath);
}

function executeStarlessOnWindow(targetWindow) {
   let tempInputFilePath  = "";
   let tempOutputFilePath = "";
   let tempStarsFilePath  = "";
   let tempJsonInfoPath   = "";

   try {
      if (!targetWindow || targetWindow.isNull)
         throw new Error("No valid target image selected.");

      if (SyQonStarlessParameters.overlap >= SyQonStarlessParameters.tileSize)
         throw new Error("Overlap must be smaller than tile size.");

      if (SyQonStarlessParameters.starlessExePath.length == 0)
         throw new Error("Please select the Starless executable with the wrench button.");

      if (!validateStarlessExecutable(SyQonStarlessParameters.starlessExePath))
         throw new Error("Selected Starless executable does not exist.");

      SyQonStarlessParameters.targetView   = targetWindow.mainView;
      SyQonStarlessParameters.targetViewId = targetWindow.mainView.id;
      SyQonStarlessParameters.save();

      let baseName = targetWindow.mainView.id;
      let runPaths = buildRunPaths(baseName);

      tempInputFilePath  = runPaths.inputFilePath;
      tempOutputFilePath = runPaths.outputFilePath;
      tempStarsFilePath  = runPaths.starsFilePath;
      tempJsonInfoPath   = runPaths.jsonInfoPath;

      saveImageAsFits(tempInputFilePath, targetWindow.mainView);

      let args = buildStarlessArgs(tempInputFilePath, tempOutputFilePath, tempStarsFilePath, tempJsonInfoPath);

      let controller = new StarlessRunController(targetWindow, runPaths);

      // Ownership of files transfers to controller now.
      tempInputFilePath  = "";
      tempOutputFilePath = "";
      tempStarsFilePath  = "";
      tempJsonInfoPath   = "";

      controller.start(SyQonStarlessParameters.starlessExePath, args);

   } catch (error) {
      console.criticalln("SyQon Starless CLI failed: " + error.message);
   } finally {
      if (tempInputFilePath.length  > 0) deleteFileIfExists(tempInputFilePath);
      if (tempOutputFilePath.length > 0) deleteFileIfExists(tempOutputFilePath);
      if (tempStarsFilePath.length  > 0) deleteFileIfExists(tempStarsFilePath);
      if (tempJsonInfoPath.length   > 0) deleteFileIfExists(tempJsonInfoPath);
   }
}

function sanitizeFileName(name) {
   return name.replace(/[^A-Za-z0-9_\-]/g, "_");
}

function deleteFileIfExists(filePath) {
   try {
      if (File.exists(filePath)) {
         File.remove(filePath);
         console.writeln("Deleted file: " + filePath);
      }
   } catch (error) {
      console.warningln("Failed to delete file: " + filePath + " -> " + error.message);
   }
}

function getActiveWindowIdSafe() {
   try {
      return ImageWindow.activeWindow.mainView.id;
   } catch (e) {
      return "";
   }
}

function ensureTempDirExists() {
   if (!File.directoryExists(scriptTempDir))
      File.createDirectory(scriptTempDir);
}

function buildRunPaths(baseName) {
   ensureTempDirExists();
   let runTag   = String((new Date()).getTime());
   let safeBase = sanitizeFileName(baseName);
   return {
      inputFilePath:  scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_input.fits",
      outputFilePath: scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_starless.fits",
      starsFilePath:  scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_stars.fits",
      jsonInfoPath:   scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_starless.json"
   };
}

// ----------------------------------------------------------------------------
// FITS save/load
// ----------------------------------------------------------------------------

function saveImageAsFits(filePath, view) {
   let imgWindow = view.isMainView ? view.window : view.mainView.window;
   if (!imgWindow)
      throw new Error("Image window is undefined for the specified view.");
   if (!imgWindow.saveAs(filePath, false, false, false, false))
      throw new Error("Failed to save image as FITS: " + filePath);
   console.writeln("Image saved as FITS: " + filePath);
   return filePath;
}

function openFitsFile(filePath, label) {
   if (!File.exists(filePath))
      throw new Error(label + " file not found: " + filePath);
   let opened = ImageWindow.open(filePath);
   if (!opened || opened.length < 1)
      throw new Error("Failed to open " + label + " image: " + filePath);
   let w = opened[0];
   w.show();
   return w;
}

// ----------------------------------------------------------------------------
// PixelMath helpers
// ----------------------------------------------------------------------------

function applyPixelMathToView(view, expr, symbols) {
   let pm = new PixelMath;
   pm.useSingleExpression         = true;
   pm.expression                  = expr;
   pm.symbols                     = symbols || "";
   pm.clearImageCacheAndExit      = false;
   pm.cacheGeneratedImages        = false;
   pm.generateOutput              = true;
   pm.singleThreaded              = false;
   pm.optimization                = true;
   pm.use64BitWorkingImage        = true;
   pm.rescale                     = false;
   pm.rescaleLower                = 0;
   pm.rescaleUpper                = 1;
   pm.truncate                    = true;
   pm.truncateLower               = 0;
   pm.truncateUpper               = 1;
   pm.createNewImage              = false;
   pm.showNewImage                = false;
   pm.newImageId                  = "";
   pm.newImageWidth               = 0;
   pm.newImageHeight              = 0;
   pm.newImageAlpha               = false;
   pm.newImageColorSpace          = PixelMath.prototype.SameAsTarget;
   pm.newImageSampleFormat        = PixelMath.prototype.SameAsTarget;
   pm.executeOn(view);
}

// ----------------------------------------------------------------------------
// Output processing
// ----------------------------------------------------------------------------

function createStarsOnlyImage(originalWindow, starlessWindow, mode) {
   if (mode == "None")
      return;

   let originalId  = originalWindow.mainView.id;
   let starlessId  = starlessWindow.mainView.id;

   let P = new PixelMath;

   if (mode == "Subtraction")
      P.expression = "(" + originalId + "-" + starlessId + ")";
   else  // Unscreen
      P.expression = "(" + originalId + "-" + starlessId + ")/(1-" + starlessId + ")";

   P.expression1              = "";
   P.expression2              = "";
   P.expression3              = "";
   P.useSingleExpression      = true;
   P.symbols                  = "";
   P.clearImageCacheAndExit   = false;
   P.cacheGeneratedImages     = false;
   P.generateOutput           = true;
   P.singleThreaded           = false;
   P.optimization             = true;
   P.use64BitWorkingImage     = false;
   P.rescale                  = false;
   P.truncate                 = true;
   P.truncateLower            = 0;
   P.truncateUpper            = 1;
   P.createNewImage           = true;
   P.showNewImage             = true;
   P.newImageId               = originalId + "_StarsOnly";
   P.newImageColorSpace       = PixelMath.prototype.SameAsTarget;
   P.newImageSampleFormat     = PixelMath.prototype.SameAsTarget;
   P.executeOn(originalWindow.mainView);
}

function overwriteTargetWithStarless(targetWindow, starlessWindow) {
   let starlessId = starlessWindow.mainView.id;

   // If original is mono but imported starless opened as color, use channel 0
   if (!targetWindow.mainView.image.isColor && starlessWindow.mainView.image.isColor)
      starlessId = starlessId + "[0]";

   let pm = new PixelMath;
   pm.useSingleExpression = true;
   pm.expression          = starlessId;
   pm.createNewImage      = false;
   pm.rescale             = false;
   pm.truncate            = false;
   pm.executeOn(targetWindow.mainView);
}

function processStarlessOutput(outputFilePath, targetWindow, starsOnlyMode) {
   let starlessWindow = openFitsFile(outputFilePath, "Starless");

   try {
      // Create stars-only FIRST using original + imported starless, then overwrite target
      if (starsOnlyMode != "None")
         createStarsOnlyImage(targetWindow, starlessWindow, starsOnlyMode);

      overwriteTargetWithStarless(targetWindow, starlessWindow);
   } finally {
      starlessWindow.forceClose();
      deleteFileIfExists(outputFilePath);
   }
}

// ----------------------------------------------------------------------------
// CLI argument construction
// ----------------------------------------------------------------------------

function buildStarlessArgs(inputFilePath, outputFilePath, starsFilePath, jsonInfoPath) {
   let args = [];

   args.push("--input");
   args.push(inputFilePath);

   args.push("--output");
   args.push(outputFilePath);

   // Always request the stars file from the CLI so it is available if needed
   args.push("--stars");
   args.push(starsFilePath);

   args.push("--tile");
   args.push(String(SyQonStarlessParameters.tileSize));

   args.push("--overlap");
   args.push(String(SyQonStarlessParameters.overlap));

   args.push("--pad");
   args.push(String(SyQonStarlessParameters.pad));

   if (SyQonStarlessParameters.useMTF) {
      args.push("--use-mtf");
      args.push("--mtf-target");
      args.push(format("%.3f", SyQonStarlessParameters.mtfTarget));
   }

   if (SyQonStarlessParameters.useAMP)
      args.push("--use-amp");

   args.push("--amp-dtype");
   args.push(SyQonStarlessParameters.ampDType);

   if (SyQonStarlessParameters.useCPU)
      args.push("--cpu");

   if (SyQonStarlessParameters.noDML)
      args.push("--no-dml");

   if (jsonInfoPath && jsonInfoPath.length > 0) {
      args.push("--json-info");
      args.push(jsonInfoPath);
   }

   return args;
}

// ----------------------------------------------------------------------------
// Async run controller  (mirrors PrismRunController exactly)
// ----------------------------------------------------------------------------

function StarlessRunController(targetWindow, runPaths) {
   this.targetWindow  = targetWindow;
   this.runPaths      = runPaths;

   this.process       = new ExternalProcess;
   this.waitDialog    = null;
   this.timer         = null;

   this.startTime     = 0;
   this.timeoutMs     = Math.max(1, SyQonStarlessParameters.outputTimeoutMinutes || 20) * 60 * 1000;

   this.canceled      = false;
   this.completed     = false;
   this.cleaned       = false;

   this.stdoutBuffer  = "";
   this.stderrBuffer  = "";
   this.lastStage     = "Starting Starless CLI...";
   this.lastPercent   = -1;
}

StarlessRunController.prototype.cleanupOnSuccess = function() {
   if (this.cleaned) return;
   this.cleaned = true;
   deleteFileIfExists(this.runPaths.inputFilePath);
   deleteFileIfExists(this.runPaths.outputFilePath);
   deleteFileIfExists(this.runPaths.starsFilePath);
   deleteFileIfExists(this.runPaths.jsonInfoPath);
};

StarlessRunController.prototype.cleanupOnCancel = function() {
   if (this.cleaned) return;
   this.cleaned = true;
   // Do NOT delete output/stars/json — CLI may still be writing them.
};

StarlessRunController.prototype.handleLine = function(line, isErrorStream) {
   if (!line) return;
   let text = line.trim();
   if (text.length == 0) return;

   let tileMatch = text.match(/^\[\s*(\d+)%\]\s+(.*?)\s+\((\d+)\/(\d+)\)$/);
   if (tileMatch) {
      this.lastPercent = parseInt(tileMatch[1], 10);
      this.lastStage   = tileMatch[2] + " (" + tileMatch[3] + "/" + tileMatch[4] + ")";
      if (this.waitDialog)
         this.waitDialog.updateStatus(this.lastStage, this.lastPercent, this.startTime, this.timeoutMs);
      return;
   }

   this.lastStage = text;
   if (this.waitDialog)
      this.waitDialog.updateStatus(this.lastStage, this.lastPercent, this.startTime, this.timeoutMs);

   Console.noteln(text);
};

StarlessRunController.prototype.processBufferedText = function(chunk, isErrorStream, which) {
   if (!chunk || chunk.length == 0) return;

   if (which == "stdout") this.stdoutBuffer += chunk;
   else                   this.stderrBuffer += chunk;

   let buffer = (which == "stdout") ? this.stdoutBuffer : this.stderrBuffer;
   let lines  = buffer.split(/\r?\n/);
   let remainder = lines.pop();

   for (let i = 0; i < lines.length; ++i)
      this.handleLine(lines[i], isErrorStream);

   if (which == "stdout") this.stdoutBuffer = remainder;
   else                   this.stderrBuffer = remainder;
};

StarlessRunController.prototype.start = function(exePath, args) {
   let self = this;

   this.process.onStandardOutputDataAvailable = function() {
      self.processBufferedText(String(this.stdout), false, "stdout");
   };

   this.process.onStandardErrorDataAvailable = function() {
      self.processBufferedText(String(this.stderr), true, "stderr");
   };

   this.process.onStarted = function() {
      Console.noteln("Starting Starless CLI...");
      Console.noteln("Executable: " + exePath);
      Console.noteln("Arguments: " + args.join(" "));
      self.lastStage = "Starless CLI started...";
      if (self.waitDialog)
         self.waitDialog.updateStatus(self.lastStage, self.lastPercent, self.startTime, self.timeoutMs);
   };

   this.process.onFinished = function() {
      if (self.stdoutBuffer.length > 0) { self.handleLine(self.stdoutBuffer, false); self.stdoutBuffer = ""; }
      if (self.stderrBuffer.length > 0) { self.handleLine(self.stderrBuffer, true);  self.stderrBuffer = ""; }
      Console.noteln("Starless CLI finished.");
   };

   this.process.onError = function(code) {
      Console.warningln("ExternalProcess reported: " + code + " (continuing to wait for output)");
   };

   this.startTime = (new Date()).getTime();

   this.waitDialog = new StarlessWaitDialog(this);
   this.waitDialog.updateStatus("Launching Starless CLI...", -1, this.startTime, this.timeoutMs);

   try {
      this.process.start(exePath, args);
   } catch (e) {
      throw new Error("Failed to start Starless CLI: " + e.message);
   }

   this.startTimer();
   this.waitDialog.execute();
};

StarlessRunController.prototype.startTimer = function() {
   let self = this;
   this.timer          = new Timer;
   this.timer.interval = 0.5;
   this.timer.periodic = true;
   this.timer.onTimeout = function() { self.poll(); };
   this.timer.start();
};

StarlessRunController.prototype.stopTimer = function() {
   try { if (this.timer) this.timer.stop(); } catch (e) {}
};

StarlessRunController.prototype.poll = function() {
   if (this.canceled || this.completed) return;

   let now     = (new Date()).getTime();
   let elapsed = now - this.startTime;

   if (this.waitDialog)
      this.waitDialog.updateStatus(this.lastStage, this.lastPercent, this.startTime, this.timeoutMs);

   // Success: output file appeared
   if (File.exists(this.runPaths.outputFilePath)) {
      this.completed = true;
      this.stopTimer();

      try { msleep(1000); } catch (e) {}

      try {
         processStarlessOutput(
            this.runPaths.outputFilePath,
            this.targetWindow,
            SyQonStarlessParameters.starsOnlyMode
         );

         if (File.exists(this.runPaths.jsonInfoPath))
            Console.noteln("Starless info JSON saved: " + this.runPaths.jsonInfoPath);

         Console.writeln("Starless processing complete on: " + this.targetWindow.mainView.id);
      } catch (e) {
         Console.criticalln("SyQon Starless CLI failed while importing output: " + e.message);
      } finally {
         this.cleanupOnSuccess();
         if (this.waitDialog) this.waitDialog.ok();
      }
      return;
   }

   // Timeout
   if (elapsed >= this.timeoutMs) {
      this.completed = true;
      this.stopTimer();
      this.cleanupOnCancel();
      if (this.waitDialog) this.waitDialog.cancel();
      Console.criticalln("SyQon Starless CLI failed: output file was not found before timeout.");
      return;
   }
};

StarlessRunController.prototype.cancelWaiting = function() {
   if (this.completed || this.canceled) return;
   this.canceled = true;
   this.stopTimer();
   this.cleanupOnCancel();
   Console.warningln("User canceled waiting for Starless output. starless_cli may still be running in the background.");
   if (this.waitDialog) this.waitDialog.cancel();
};

// ----------------------------------------------------------------------------
// Wait dialog
// ----------------------------------------------------------------------------

function formatElapsed(ms) {
   let s = Math.max(0, Math.floor(ms / 1000));
   let h = Math.floor(s / 3600); s -= h * 3600;
   let m = Math.floor(s / 60);   s -= m * 60;
   if (h > 0) return format("%d:%02d:%02d", h, m, s);
   return format("%02d:%02d", m, s);
}

function StarlessWaitDialog(controller) {
   this.__base__ = Dialog;
   this.__base__();

   let self = this;
   this.controller    = controller;
   this.windowTitle   = "SyQon Starless \u2014 Processing";
   this.userResizable = false;
   this.minWidth      = 560;

   this.waitHeaderLabel = new Label(this);
   this.waitHeaderLabel.useRichText    = true;
   this.waitHeaderLabel.textAlignment  = TextAlign_Center;
   this.waitHeaderLabel.text =
      "<b><font size='+1'>\u2605 SyQon Starless \u2605</font></b><br/>" +
      "<font size='-1'>Processing in progress...</font>";

   this.headerSep = new Frame(this);
   this.headerSep.frameStyle = FrameStyle_Box;
   this.headerSep.setFixedHeight(2);

   this.statusGroup       = new GroupBox(this);
   this.statusGroup.title = "Status";

   this.infoLabel = new Label(this);
   this.infoLabel.useRichText  = true;
   this.infoLabel.wordWrapping = true;
   this.infoLabel.text         = "<i>Waiting for Starless output...</i>";

   this.progressLabel = new Label(this);
   this.progressLabel.useRichText = true;
   this.progressLabel.text        = "<b>Progress:</b> starting...";

   this.progressBarLabel = new Label(this);
   this.progressBarLabel.useRichText = false;
   this.progressBarLabel.text        = "";

   this.elapsedLabel = new Label(this);
   this.elapsedLabel.useRichText = true;
   this.elapsedLabel.text        = "<b>Elapsed:</b> 00:00";

   this.statusGroup.sizer = new VerticalSizer;
   this.statusGroup.sizer.margin  = 8;
   this.statusGroup.sizer.spacing = 6;
   this.statusGroup.sizer.add(this.infoLabel);
   this.statusGroup.sizer.add(this.progressLabel);
   this.statusGroup.sizer.add(this.progressBarLabel);
   this.statusGroup.sizer.add(this.elapsedLabel);

   this.noteLabel = new Label(this);
   this.noteLabel.useRichText  = true;
   this.noteLabel.wordWrapping = true;
   this.noteLabel.text =
      "<i>Cancel stops waiting and closes this script.<br/>" +
      "It does not terminate starless_cli if it is already running.</i>";

   this.cancelButton = new PushButton(this);
   this.cancelButton.text = "Cancel";
   this.cancelButton.onClick = function() { self.controller.cancelWaiting(); };

   this.sizer = new VerticalSizer;
   this.sizer.margin  = 12;
   this.sizer.spacing = 8;
   this.sizer.add(this.waitHeaderLabel);
   this.sizer.add(this.headerSep);
   this.sizer.addSpacing(4);
   this.sizer.add(this.statusGroup);
   this.sizer.addSpacing(4);
   this.sizer.add(this.noteLabel);
   this.sizer.addSpacing(8);

   this.buttonSizer = new HorizontalSizer;
   this.buttonSizer.addStretch();
   this.buttonSizer.add(this.cancelButton);
   this.buttonSizer.addStretch();
   this.sizer.add(this.buttonSizer);

   this.adjustToContents();
}
StarlessWaitDialog.prototype = new Dialog;

StarlessWaitDialog.prototype.updateStatus = function(stage, percent, startTime, timeoutMs) {
   let now     = (new Date()).getTime();
   let elapsed = now - startTime;
   let remain  = Math.max(0, timeoutMs - elapsed);

   this.infoLabel.text = "<i>Starless is running...</i>";
   this.progressLabel.text =
      (percent >= 0)
         ? ("<b>Progress:</b> " + stage + "  [<b>" + percent + "%</b>]")
         : ("<b>Progress:</b> " + stage);

   if (percent >= 0) {
      let barLen = 40;
      let filled = Math.round(barLen * percent / 100);
      let bar = "";
      for (let i = 0; i < barLen; i++)
         bar += (i < filled) ? "\u2588" : "\u2591";
      this.progressBarLabel.text = bar + "  " + percent + "%";
   } else {
      this.progressBarLabel.text = "";
   }

   this.elapsedLabel.text =
      "<b>Elapsed:</b> " + formatElapsed(elapsed) +
      "    <b>Timeout in:</b> " + formatElapsed(remain);
};

// ----------------------------------------------------------------------------
// Main dialog
// ----------------------------------------------------------------------------

function SyQonStarlessDialog() {
   this.__base__ = Dialog;
   this.__base__();

   let self = this;

   SyQonStarlessParameters.load();

   this._windowIds = [];

   this.syncToParameters = function() {
      SyQonStarlessParameters.tileSize             = this.tileSpin.value;
      SyQonStarlessParameters.overlap              = this.overlapSpin.value;
      SyQonStarlessParameters.pad                  = this.padSpin.value;
      SyQonStarlessParameters.useMTF               = this.useMTFCheckbox.checked;
      SyQonStarlessParameters.mtfTarget            = this.mtfTargetSpin.value;
      SyQonStarlessParameters.useAMP               = this.useAMPCheckbox.checked;
      SyQonStarlessParameters.ampDType             = this.ampDTypeCombo.itemText(this.ampDTypeCombo.currentItem);
      SyQonStarlessParameters.useCPU               = this.useCPUCheckbox.checked;
      SyQonStarlessParameters.noDML                = this.noDMLCheckbox.checked;
      SyQonStarlessParameters.starsOnlyMode        = this.starsOnlyModeCombo.itemText(this.starsOnlyModeCombo.currentItem);
      SyQonStarlessParameters.outputTimeoutMinutes = this.outputTimeoutSpin.value;

      let w = getSelectedWindowFromDialog(this);
      if (w && !w.isNull) {
         SyQonStarlessParameters.targetView   = w.mainView;
         SyQonStarlessParameters.targetViewId = w.mainView.id;
      }

      SyQonStarlessParameters.save();
   };

   this.selectViewById = function(viewId) {
      if (!viewId || viewId.length == 0) return false;
      for (let i = 0; i < this._windowIds.length; ++i) {
         if (this._windowIds[i] == viewId) {
            this.imageSelectionDropdown.currentItem = i;
            return true;
         }
      }
      return false;
   };

   // =====================================================================
   // Header
   // =====================================================================
   this.headerLabel = new Label(this);
   this.headerLabel.useRichText   = true;
   this.headerLabel.textAlignment = TextAlign_Center;
   this.headerLabel.text =
      "<b><font size='+2'>\u2605 SyQon Starless \u2605</font></b><br/>" +
      "<font size='-1'>Axiom V2.1</font>";

   this.headerSeparator = new Frame(this);
   this.headerSeparator.frameStyle = FrameStyle_Box;
   this.headerSeparator.setFixedHeight(2);

   // =====================================================================
   // Image selection
   // =====================================================================
   this.imageSelectionLabel = new Label(this);
   this.imageSelectionLabel.text          = "Target Image:";
   this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.imageSelectionDropdown = new ComboBox(this);
   this.imageSelectionDropdown.editEnabled = false;

   let windows        = ImageWindow.windows;
   let activeWindowId = getActiveWindowIdSafe();
   for (let i = 0; i < windows.length; ++i) {
      let wid = windows[i].mainView.id;
      this.imageSelectionDropdown.addItem(wid);
      this._windowIds.push(wid);
      if (wid == activeWindowId)
         this.imageSelectionDropdown.currentItem = i;
   }

   this.imageSelectionSizer = new HorizontalSizer;
   this.imageSelectionSizer.spacing = 4;
   this.imageSelectionSizer.add(this.imageSelectionLabel);
   this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

   // =====================================================================
   // Tile size
   // =====================================================================
   this.tileLabel = new Label(this);
   this.tileLabel.text          = "Tile Size:";
   this.tileLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.tileSpin = new SpinBox(this);
   this.tileSpin.minValue = 128;
   this.tileSpin.maxValue = 2048;
   this.tileSpin.stepSize = 64;
   this.tileSpin.value    = SyQonStarlessParameters.tileSize;
   this.tileSpin.onValueUpdated = function(value) { SyQonStarlessParameters.tileSize = value; };

   this.tileSizer = new HorizontalSizer;
   this.tileSizer.spacing = 4;
   this.tileSizer.add(this.tileLabel);
   this.tileSizer.add(this.tileSpin);
   this.tileSizer.addStretch();

   // =====================================================================
   // Overlap
   // =====================================================================
   this.overlapLabel = new Label(this);
   this.overlapLabel.text          = "Overlap:";
   this.overlapLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.overlapSpin = new SpinBox(this);
   this.overlapSpin.minValue = 8;
   this.overlapSpin.maxValue = 512;
   this.overlapSpin.stepSize = 8;
   this.overlapSpin.value    = SyQonStarlessParameters.overlap;
   this.overlapSpin.onValueUpdated = function(value) { SyQonStarlessParameters.overlap = value; };

   this.overlapSizer = new HorizontalSizer;
   this.overlapSizer.spacing = 4;
   this.overlapSizer.add(this.overlapLabel);
   this.overlapSizer.add(this.overlapSpin);
   this.overlapSizer.addStretch();

   // =====================================================================
   // Pad
   // =====================================================================
   this.padLabel = new Label(this);
   this.padLabel.text          = "Pad:";
   this.padLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.padSpin = new SpinBox(this);
   this.padSpin.minValue = 0;
   this.padSpin.maxValue = 2048;
   this.padSpin.stepSize = 8;
   this.padSpin.value    = SyQonStarlessParameters.pad;
   this.padSpin.onValueUpdated = function(value) { SyQonStarlessParameters.pad = value; };

   this.padSizer = new HorizontalSizer;
   this.padSizer.spacing = 4;
   this.padSizer.add(this.padLabel);
   this.padSizer.add(this.padSpin);
   this.padSizer.addStretch();

   // =====================================================================
   // Temp stretch
   // =====================================================================
   this.useMTFCheckbox = new CheckBox(this);
   this.useMTFCheckbox.text    = "Use PI Temp Stretch";
   this.useMTFCheckbox.checked = SyQonStarlessParameters.useMTF;
   this.useMTFCheckbox.toolTip = "Applies a temporary stretch before sending to Starless, then reverses it afterward. Recommended for linear data.";
   this.useMTFCheckbox.onCheck = function(checked) {
      SyQonStarlessParameters.useMTF = checked;
      self.mtfTargetSpin.enabled = checked;
   };

   this.mtfTargetLabel = new Label(this);
   this.mtfTargetLabel.text          = "MTF Target:";
   this.mtfTargetLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.mtfTargetSpin = new NumericControl(this);
   this.mtfTargetSpin.label.text = "";
   this.mtfTargetSpin.setRange(0.01, 0.50);
   this.mtfTargetSpin.slider.setRange(1, 50);
   this.mtfTargetSpin.setPrecision(3);
   this.mtfTargetSpin.setValue(SyQonStarlessParameters.mtfTarget);
   this.mtfTargetSpin.enabled = SyQonStarlessParameters.useMTF;
   this.mtfTargetSpin.onValueUpdated = function(value) { SyQonStarlessParameters.mtfTarget = value; };

   this.mtfTargetSizer = new HorizontalSizer;
   this.mtfTargetSizer.spacing = 4;
   this.mtfTargetSizer.add(this.mtfTargetLabel);
   this.mtfTargetSizer.add(this.mtfTargetSpin, 100);

   // =====================================================================
   // Stars only mode
   // =====================================================================
   this.starsOnlyModeLabel = new Label(this);
   this.starsOnlyModeLabel.text          = "Stars Only:";
   this.starsOnlyModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.starsOnlyModeCombo = new ComboBox(this);
   this.starsOnlyModeCombo.addItem("None");
   this.starsOnlyModeCombo.addItem("Subtraction");
   this.starsOnlyModeCombo.addItem("Unscreen");

   let somIndex = 1;
   if      (SyQonStarlessParameters.starsOnlyMode == "None")        somIndex = 0;
   else if (SyQonStarlessParameters.starsOnlyMode == "Subtraction") somIndex = 1;
   else if (SyQonStarlessParameters.starsOnlyMode == "Unscreen")    somIndex = 2;
   this.starsOnlyModeCombo.currentItem = somIndex;
   SyQonStarlessParameters.starsOnlyMode = this.starsOnlyModeCombo.itemText(somIndex);

   this.starsOnlyModeCombo.onItemSelected = function(index) {
      SyQonStarlessParameters.starsOnlyMode = this.itemText(index);
   };

   this.starsOnlyModeSizer = new HorizontalSizer;
   this.starsOnlyModeSizer.spacing = 4;
   this.starsOnlyModeSizer.add(this.starsOnlyModeLabel);
   this.starsOnlyModeSizer.add(this.starsOnlyModeCombo, 100);

   // =====================================================================
   // AMP
   // =====================================================================
   this.useAMPCheckbox = new CheckBox(this);
   this.useAMPCheckbox.text    = "Use AMP";
   this.useAMPCheckbox.checked = SyQonStarlessParameters.useAMP;
   this.useAMPCheckbox.toolTip = "Use mixed precision where supported (accepted by CLI; ONNX path ignores).";
   this.useAMPCheckbox.onCheck = function(checked) {
      SyQonStarlessParameters.useAMP = checked;
      self.ampDTypeCombo.enabled = checked;
   };

   this.ampDTypeLabel = new Label(this);
   this.ampDTypeLabel.text          = "AMP Type:";
   this.ampDTypeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.ampDTypeCombo = new ComboBox(this);
   this.ampDTypeCombo.addItem("fp16");
   this.ampDTypeCombo.addItem("bf16");
   this.ampDTypeCombo.currentItem = (SyQonStarlessParameters.ampDType == "bf16") ? 1 : 0;
   this.ampDTypeCombo.enabled     = SyQonStarlessParameters.useAMP;
   this.ampDTypeCombo.onItemSelected = function(index) {
      SyQonStarlessParameters.ampDType = this.itemText(index);
   };

   this.ampSizer = new HorizontalSizer;
   this.ampSizer.spacing = 4;
   this.ampSizer.add(this.ampDTypeLabel);
   this.ampSizer.add(this.ampDTypeCombo, 100);

   // =====================================================================
   // CPU / DML
   // =====================================================================
   this.useCPUCheckbox = new CheckBox(this);
   this.useCPUCheckbox.text    = "Force CPU";
   this.useCPUCheckbox.checked = SyQonStarlessParameters.useCPU;
   this.useCPUCheckbox.toolTip = "Force CPU inference.";
   this.useCPUCheckbox.onCheck = function(checked) { SyQonStarlessParameters.useCPU = checked; };

   this.noDMLCheckbox = new CheckBox(this);
   this.noDMLCheckbox.text    = "Disable DirectML";
   this.noDMLCheckbox.checked = SyQonStarlessParameters.noDML;
   this.noDMLCheckbox.toolTip = "Disable DirectML preference on Windows.";
   this.noDMLCheckbox.onCheck = function(checked) { SyQonStarlessParameters.noDML = checked; };

   // =====================================================================
   // Output timeout
   // =====================================================================
   this.outputTimeoutLabel = new Label(this);
   this.outputTimeoutLabel.text          = "Output Timeout (min):";
   this.outputTimeoutLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.outputTimeoutSpin = new SpinBox(this);
   this.outputTimeoutSpin.minValue  = 1;
   this.outputTimeoutSpin.maxValue  = 240;
   this.outputTimeoutSpin.stepSize  = 1;
   this.outputTimeoutSpin.value     = SyQonStarlessParameters.outputTimeoutMinutes;
   this.outputTimeoutSpin.toolTip   = "Maximum time to wait for the Starless output file before aborting.";
   this.outputTimeoutSpin.onValueUpdated = function(value) { SyQonStarlessParameters.outputTimeoutMinutes = value; };

   this.outputTimeoutSizer = new HorizontalSizer;
   this.outputTimeoutSizer.spacing = 4;
   this.outputTimeoutSizer.add(this.outputTimeoutLabel);
   this.outputTimeoutSizer.add(this.outputTimeoutSpin);
   this.outputTimeoutSizer.addStretch();

   // =====================================================================
   // Open dialog checkbox
   // =====================================================================
   this.openDialogCheckbox = new CheckBox(this);
   this.openDialogCheckbox.text    = "Open dialog when instance is double-clicked or dropped";
   this.openDialogCheckbox.checked = SyQonStarlessParameters.openDialogBox;
   this.openDialogCheckbox.toolTip =
      "If enabled, a saved process instance opens this dialog first.\n" +
      "If disabled, dropping a process instance on a view will run immediately.";
   this.openDialogCheckbox.onCheck = function(checked) { SyQonStarlessParameters.openDialogBox = checked; };

   // =====================================================================
   // Executable
   // =====================================================================
   this.setupButton = new ToolButton(this);
   this.setupButton.icon = this.scaledResource(":/icons/wrench.png");
   this.setupButton.setScaledFixedSize(24, 24);
   this.setupButton.toolTip = "Select the starless_cli executable file.";
   this.setupButton.onClick = function() {
      let ofd = new OpenFileDialog;
      ofd.caption           = "Select Starless Executable";
      ofd.multipleSelections = false;
      if (SyQonStarlessParameters.starlessExePath.length > 0)
         ofd.initialPath = SyQonStarlessParameters.starlessExePath;
      if (IS_WINDOWS)
         ofd.filters = [ ["Executable Files", "*.exe"], ["All Files", "*"] ];
      else
         ofd.filters = [ ["All Files", "*"] ];
      if (ofd.execute()) {
         SyQonStarlessParameters.starlessExePath = ofd.fileName;
         SyQonStarlessParameters.save();
         self.exePathLabel.text = SyQonStarlessParameters.starlessExePath;
      }
   };

   this.exePathLabel = new TextBox(this);
   this.exePathLabel.readOnly     = true;
   this.exePathLabel.setFixedHeight(48);
   this.exePathLabel.text =
      SyQonStarlessParameters.starlessExePath.length > 0
         ? SyQonStarlessParameters.starlessExePath
         : "No Starless executable selected.";

   this.exePathSizer = new HorizontalSizer;
   this.exePathSizer.spacing = 6;
   this.exePathSizer.add(this.setupButton);
   this.exePathSizer.add(this.exePathLabel, 100);

   // =====================================================================
   // Buttons
   // =====================================================================
   this.okButton = new PushButton(this);
   this.okButton.text = "OK";
   this.okButton.onClick = function() {
      self.syncToParameters();
      self.ok();
   };

   this.cancelButton = new PushButton(this);
   this.cancelButton.text    = "Cancel";
   this.cancelButton.onClick = function() { self.cancel(); };

   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "Drag to workspace to create a new process instance";
   this.newInstanceButton.onMousePress = function() {
      self.syncToParameters();
      self.newInstance();
   };

   this.buttonsSizer = new HorizontalSizer;
   this.buttonsSizer.spacing = 6;
   this.buttonsSizer.add(this.newInstanceButton);
   this.buttonsSizer.addStretch();
   this.buttonsSizer.add(this.okButton);
   this.buttonsSizer.add(this.cancelButton);

   // =====================================================================
   // Label width alignment
   // =====================================================================
   let labelWidth = this.font.width("Output Timeout (min):MMMM");
   this.imageSelectionLabel.setFixedWidth(labelWidth);
   this.tileLabel.setFixedWidth(labelWidth);
   this.overlapLabel.setFixedWidth(labelWidth);
   this.padLabel.setFixedWidth(labelWidth);
   this.mtfTargetLabel.setFixedWidth(labelWidth);
   this.starsOnlyModeLabel.setFixedWidth(labelWidth);
   this.ampDTypeLabel.setFixedWidth(labelWidth);
   this.outputTimeoutLabel.setFixedWidth(labelWidth);

   // =====================================================================
   // GroupBox: Target Image
   // =====================================================================
   this.imageGroup = new GroupBox(this);
   this.imageGroup.title = "Target Image";
   this.imageGroup.sizer = new VerticalSizer;
   this.imageGroup.sizer.margin  = 6;
   this.imageGroup.sizer.spacing = 4;
   this.imageGroup.sizer.add(this.imageSelectionSizer);

   // =====================================================================
   // GroupBox: Model Settings
   // =====================================================================
   this.modelGroup = new GroupBox(this);
   this.modelGroup.title = "Model Settings  (Axiom V2.1)";
   this.modelGroup.sizer = new VerticalSizer;
   this.modelGroup.sizer.margin  = 6;
   this.modelGroup.sizer.spacing = 4;
   this.modelGroup.sizer.add(this.tileSizer);
   this.modelGroup.sizer.add(this.overlapSizer);
   this.modelGroup.sizer.add(this.padSizer);

   // =====================================================================
   // GroupBox: Starless
   // =====================================================================
   this.starlessGroup = new GroupBox(this);
   this.starlessGroup.title = "Starless";
   this.starlessGroup.sizer = new VerticalSizer;
   this.starlessGroup.sizer.margin  = 6;
   this.starlessGroup.sizer.spacing = 4;
   this.starlessGroup.sizer.add(this.useMTFCheckbox);
   this.starlessGroup.sizer.add(this.mtfTargetSizer);
   this.starlessGroup.sizer.add(this.starsOnlyModeSizer);

   // =====================================================================
   // GroupBox: Performance
   // =====================================================================
   this.performanceGroup = new GroupBox(this);
   this.performanceGroup.title = "Performance";
   this.performanceGroup.sizer = new VerticalSizer;
   this.performanceGroup.sizer.margin  = 6;
   this.performanceGroup.sizer.spacing = 4;
   this.performanceGroup.sizer.add(this.useAMPCheckbox);
   this.performanceGroup.sizer.add(this.ampSizer);
   this.performanceGroup.sizer.add(this.useCPUCheckbox);
   this.performanceGroup.sizer.add(this.noDMLCheckbox);

   // =====================================================================
   // GroupBox: Advanced
   // =====================================================================
   this.advancedGroup = new GroupBox(this);
   this.advancedGroup.title = "Advanced";
   this.advancedGroup.sizer = new VerticalSizer;
   this.advancedGroup.sizer.margin  = 6;
   this.advancedGroup.sizer.spacing = 4;
   this.advancedGroup.sizer.add(this.outputTimeoutSizer);
   this.advancedGroup.sizer.add(this.openDialogCheckbox);

   // =====================================================================
   // GroupBox: Starless Executable
   // =====================================================================
   this.executableGroup = new GroupBox(this);
   this.executableGroup.title = "Starless Executable";
   this.executableGroup.sizer = new VerticalSizer;
   this.executableGroup.sizer.margin  = 6;
   this.executableGroup.sizer.spacing = 4;
   this.executableGroup.sizer.add(this.exePathSizer);

   // =====================================================================
   // Copyright footer
   // =====================================================================
   this.copyrightLabel = new Label(this);
   this.copyrightLabel.useRichText    = true;
   this.copyrightLabel.textAlignment  = TextAlign_Center;
   this.copyrightLabel.text =
      "<font size='-1'>\u00A9 SyQon 2026 \u2014 www.syqon.it</font>";

   // =====================================================================
   // Main layout
   // =====================================================================
   this.sizer = new VerticalSizer;
   this.sizer.margin  = 12;
   this.sizer.spacing = 8;
   this.sizer.add(this.headerLabel);
   this.sizer.add(this.headerSeparator);
   this.sizer.addSpacing(4);
   this.sizer.add(this.imageGroup);
   this.sizer.add(this.modelGroup);
   this.sizer.add(this.starlessGroup);
   this.sizer.add(this.performanceGroup);
   this.sizer.add(this.advancedGroup);
   this.sizer.add(this.executableGroup);
   this.sizer.addSpacing(8);
   this.sizer.add(this.buttonsSizer);
   this.sizer.addSpacing(2);
   this.sizer.add(this.copyrightLabel);

   this.windowTitle = "SyQon Starless ";
   this.setMinWidth(560);
   this.adjustToContents();

   if (SyQonStarlessParameters.targetViewId && SyQonStarlessParameters.targetViewId.length > 0)
      this.selectViewById(SyQonStarlessParameters.targetViewId);
}
SyQonStarlessDialog.prototype = new Dialog;

// ----------------------------------------------------------------------------
// Main
// ----------------------------------------------------------------------------

function main() {
   console.show();
   Console.criticalln(" ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗");
   Console.criticalln(" ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║");
   Console.criticalln(" ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║");
   Console.warningln(" ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║");
   Console.warningln(" ███████║   ██║   ╚██████╔╝╚█████╔╝ ██║ ╚████║");
   Console.warningln(" ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝");
   Console.noteln("Starting SyQon \u2605 S T A R L E S S \u2605  " + VERSION);
   Console.noteln("\u00A9 SyQon 2026 \u2014 www.syqon.it");
   console.flush();

   SyQonStarlessParameters.load();

   if (Parameters.isGlobalTarget) {
      Console.criticalln("This script cannot run in a global context.");
      return;
   }

   // View-targeted instance
   if (Parameters.isViewTarget && Parameters.targetView) {
      SyQonStarlessParameters.targetView   = Parameters.targetView;
      SyQonStarlessParameters.targetViewId = Parameters.targetView.id;
      SyQonStarlessParameters.save();

      if (SyQonStarlessParameters.openDialogBox) {
         let dlg = new SyQonStarlessDialog();
         dlg.selectViewById(SyQonStarlessParameters.targetViewId);

         if (dlg.execute()) {
            let selectedWindow = getSelectedWindowFromDialog(dlg);
            if (!selectedWindow)
               selectedWindow = resolveWindowFromViewId(SyQonStarlessParameters.targetViewId);
            executeStarlessOnWindow(selectedWindow);
         } else {
            Console.noteln("SyQon Starless dialog closed.");
         }
         return;
      }

      let targetWindow = Parameters.targetView.window;
      executeStarlessOnWindow(targetWindow);
      return;
   }

   // Normal interactive launch
   let dlg = new SyQonStarlessDialog();
   if (dlg.execute()) {
      let selectedWindow = getSelectedWindowFromDialog(dlg);

      if (!selectedWindow && SyQonStarlessParameters.targetViewId.length > 0)
         selectedWindow = resolveWindowFromViewId(SyQonStarlessParameters.targetViewId);

      if (!selectedWindow)
         throw new Error("Please select an image.");

      executeStarlessOnWindow(selectedWindow);
   } else {
      Console.noteln("SyQon Starless dialog closed.");
   }
}

main();
