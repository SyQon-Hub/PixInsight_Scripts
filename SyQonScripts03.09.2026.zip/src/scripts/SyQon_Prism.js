#feature-id SyQonPrism : SyQon > Prism
#feature-icon  syqonprism.svg
#feature-info This script integrates with the SyQon Prism CLI application to denoise images.

/****************************************************************************
 * ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗
 * ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║
 * ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║
 * ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║
 * ███████║   ██║   ╚██████╔╝╚██████╔╝██║ ╚████║
 * ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝
 *        ★  P R I S M  ★
 *
 * SyQon Prism CLI PixInsight Integration
 * Version: v1.0
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script integrates with the SyQon Prism CLI application.
 * It saves the current image as a temporary FITS file, runs Prism
 * headlessly with the selected options, and then imports the denoised
 * result back into the target image.
 *
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>

#define VERSION "v1.0"

// ----------------------------------------------------------------------------
// Platform helpers
// ----------------------------------------------------------------------------

let IS_WINDOWS = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows");
let IS_MACOS   = (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS");
let IS_LINUX   = (CoreApplication.platform == "Linux");

if (!IS_WINDOWS && !IS_MACOS && !IS_LINUX)
   console.criticalln("Unsupported platform: " + CoreApplication.platform);

let pathSeparator = IS_WINDOWS ? "\\" : "/";

// ----------------------------------------------------------------------------
// Temp/config paths
// ----------------------------------------------------------------------------

let scriptTempDir = File.systemTempDirectory + pathSeparator + "SyQonPrismCLI";
let syqonPrismConfigFile = scriptTempDir + pathSeparator + "syqon_prism_config.csv";

if (!File.directoryExists(scriptTempDir))
   File.createDirectory(scriptTempDir);

// ----------------------------------------------------------------------------
// Parameters
// ----------------------------------------------------------------------------

var SyQonPrismParameters = {
   targetView: undefined,
   prismExePath: "",
   modelKind: "prism_deep",
   tileSize: 512,
   overlap: 64,
   pad: 96,
   strength: 0.85,
   useMTF: true,
   mtfTarget: 0.10,
   useAMP: true,
   ampDType: "fp16",
   useCPU: false,
   noDML: false,
   outputTimeoutMinutes: 20,

   save: function() {
      Parameters.set("prismExePath", this.prismExePath);
      Parameters.set("modelKind", this.modelKind);
      Parameters.set("tileSize", this.tileSize);
      Parameters.set("overlap", this.overlap);
      Parameters.set("pad", this.pad);
      Parameters.set("strength", this.strength);
      Parameters.set("useMTF", this.useMTF);
      Parameters.set("mtfTarget", this.mtfTarget);
      Parameters.set("useAMP", this.useAMP);
      Parameters.set("ampDType", this.ampDType);
      Parameters.set("useCPU", this.useCPU);
      Parameters.set("noDML", this.noDML);
      Parameters.set("outputTimeoutMinutes", this.outputTimeoutMinutes);
      this.savePathToFile();
   },

   load: function() {
      if (Parameters.has("prismExePath"))
         this.prismExePath = Parameters.getString("prismExePath");
      if (Parameters.has("modelKind"))
         this.modelKind = Parameters.getString("modelKind");
      if (Parameters.has("tileSize"))
         this.tileSize = Parameters.getInteger("tileSize");
      if (Parameters.has("overlap"))
         this.overlap = Parameters.getInteger("overlap");
      if (Parameters.has("pad"))
         this.pad = Parameters.getInteger("pad");
      if (Parameters.has("strength"))
         this.strength = Parameters.getReal("strength");
      if (Parameters.has("useMTF"))
         this.useMTF = Parameters.getBoolean("useMTF");
      if (Parameters.has("mtfTarget"))
         this.mtfTarget = Parameters.getReal("mtfTarget");
      if (Parameters.has("useAMP"))
         this.useAMP = Parameters.getBoolean("useAMP");
      if (Parameters.has("ampDType"))
         this.ampDType = Parameters.getString("ampDType");
      if (Parameters.has("useCPU"))
         this.useCPU = Parameters.getBoolean("useCPU");
      if (Parameters.has("noDML"))
         this.noDML = Parameters.getBoolean("noDML");
      if (Parameters.has("outputTimeoutMinutes"))
         this.outputTimeoutMinutes = Parameters.getInteger("outputTimeoutMinutes");
      this.loadPathFromFile();
   },

   savePathToFile: function() {
      try {
         let file = new File;
         file.createForWriting(syqonPrismConfigFile);
         file.outTextLn(this.prismExePath);
         file.close();
      } catch (error) {
         console.warningln("Failed to save Prism executable path: " + error.message);
      }
   },

   loadPathFromFile: function() {
      try {
         if (File.exists(syqonPrismConfigFile)) {
            let lines = File.readLines(syqonPrismConfigFile);
            if (lines.length > 0)
               this.prismExePath = lines[0].trim();
         }
      } catch (error) {
         console.warningln("Failed to load Prism executable path: " + error.message);
      }
   }
};

// ----------------------------------------------------------------------------
// Utility helpers
// ----------------------------------------------------------------------------

function sanitizeFileName(name) {
   return name.replace(/[^A-Za-z0-9_\-]/g, "_");
}

function deleteFileIfExists(filePath) {
   try {
      if (File.exists(filePath)) {
         File.remove(filePath);
         console.writeln("Deleted file: " + filePath);
      }
   } catch (error) {
      console.warningln("Failed to delete file: " + filePath + " -> " + error.message);
   }
}

function waitForFile(filePath, timeoutMs) {
   let start = (new Date()).getTime();
   let pollingInterval = 500;

   while (((new Date()).getTime() - start) < timeoutMs) {
      if (File.exists(filePath)) {
         console.writeln("Output file found: " + filePath);
         msleep(1000);
         return true;
      }
      processEvents();
      msleep(pollingInterval);
   }

   return false;
}

function getActiveWindowIdSafe() {
   try {
      return ImageWindow.activeWindow.mainView.id;
   } catch (e) {
      return "";
   }
}

function ensureTempDirExists() {
   if (!File.directoryExists(scriptTempDir))
      File.createDirectory(scriptTempDir);
}

function buildRunPaths(baseName) {
   ensureTempDirExists();

   let runTag = String((new Date()).getTime());
   let safeBase = sanitizeFileName(baseName);

   return {
      inputFilePath:  scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_input.fits",
      outputFilePath: scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_prism.fits",
      jsonInfoPath:   scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_prism.json"
   };
}

// ----------------------------------------------------------------------------
// Executable resolution
// ----------------------------------------------------------------------------

function validatePrismExecutable(exePath) {
   if (!exePath || exePath.length == 0)
      return false;
   return File.exists(exePath);
}

// ----------------------------------------------------------------------------
// FITS save/load
// ----------------------------------------------------------------------------

function saveImageAsFits(filePath, view) {
   let imgWindow = view.isMainView ? view.window : view.mainView.window;
   if (!imgWindow)
      throw new Error("Image window is undefined for the specified view.");

   if (!imgWindow.saveAs(filePath, false, false, false, false))
      throw new Error("Failed to save image as FITS: " + filePath);

   console.writeln("Image saved as FITS: " + filePath);
   return filePath;
}

function prismReferenceExpression(targetView, prismWindow) {
   if (!targetView.image.isColor && prismWindow.mainView.image.isColor)
      return prismWindow.mainView.id + "[0]";
   return prismWindow.mainView.id;
}

function openPrismOutput(outputFilePath) {
   if (!File.exists(outputFilePath))
      throw new Error("Prism output file not found: " + outputFilePath);

   let opened = ImageWindow.open(outputFilePath);
   if (!opened || opened.length < 1)
      throw new Error("Failed to open Prism output image: " + outputFilePath);

   let outWindow = opened[0];
   outWindow.show();
   return outWindow;
}

function overwriteTargetWithPrism(targetWindow, prismWindow) {
   let targetView = targetWindow.mainView;
   let expr = prismReferenceExpression(targetView, prismWindow);

   let pm = new PixelMath;
   pm.useSingleExpression = true;
   pm.createNewImage = false;
   pm.rescale = false;
   pm.truncate = false;
   pm.expression = expr;
   pm.executeOn(targetView);
}

function processPrismOutput(outputFilePath, targetWindow) {
   let prismWindow = openPrismOutput(outputFilePath);
   overwriteTargetWithPrism(targetWindow, prismWindow);
   prismWindow.forceClose();
   deleteFileIfExists(outputFilePath);
}

// ----------------------------------------------------------------------------
// CLI argument construction
// ----------------------------------------------------------------------------

function buildPrismArgs(inputFilePath, outputFilePath, jsonInfoPath) {
   let args = [];

   args.push("--input");
   args.push(inputFilePath);

   args.push("--output");
   args.push(outputFilePath);

   args.push("--model-kind");
   args.push(SyQonPrismParameters.modelKind);

   args.push("--tile");
   args.push(String(SyQonPrismParameters.tileSize));

   args.push("--overlap");
   args.push(String(SyQonPrismParameters.overlap));

   args.push("--pad");
   args.push(String(SyQonPrismParameters.pad));

   args.push("--strength");
   args.push(format("%.2f", SyQonPrismParameters.strength));

   if (SyQonPrismParameters.useMTF)
      args.push("--use-mtf");

   args.push("--mtf-target");
   args.push(format("%.3f", SyQonPrismParameters.mtfTarget));

   if (SyQonPrismParameters.useAMP)
      args.push("--use-amp");

   args.push("--amp-dtype");
   args.push(SyQonPrismParameters.ampDType);

   if (SyQonPrismParameters.useCPU)
      args.push("--cpu");

   if (SyQonPrismParameters.noDML)
      args.push("--no-dml");

   if (jsonInfoPath && jsonInfoPath.length > 0) {
      args.push("--json-info");
      args.push(jsonInfoPath);
   }

   return args;
}

// ----------------------------------------------------------------------------
// External process runner
// ----------------------------------------------------------------------------
function runPrismProcess(exePath, args, expectedOutputFilePath, outputTimeoutMinutes) {
   let process = new ExternalProcess;
   let lastProgress = "";
   let showedFinalizeMessage = false;

   process.onStandardOutputDataAvailable = function() {
      let output = String(this.stdout);
      if (!output || output.length == 0)
         return;

      // Example:
      // [ 12%] SyQon Prism tiles... (3/25)
      let match = output.match(/\[\s*(\d+)%\]\s+.*\((\d+)\/(\d+)\)/);
      if (match) {
         let percentage = parseInt(match[1], 10);
         let processed  = parseInt(match[2], 10);
         let total      = parseInt(match[3], 10);

         let remaining = total - processed;
         let newProgress = "";

         if (remaining <= 3) {
            newProgress = "Finalizing: waiting for Prism to stitch and export the file...";
            showedFinalizeMessage = true;
         } else {
            newProgress = format("Progress: %3d%% (%4d/%4d tiles)", percentage, processed, total);
         }

         let backspaces = "";
         for (let i = 0; i < lastProgress.length; i++)
            backspaces += "\b";

         // If the new message is shorter than the old one, pad with spaces so old text is erased
         let paddedProgress = newProgress;
         if (lastProgress.length > newProgress.length) {
            for (let j = 0; j < lastProgress.length - newProgress.length; ++j)
               paddedProgress += " ";
         }

         Console.write(backspaces + paddedProgress);
         lastProgress = newProgress;
      } else {
         if (lastProgress.length > 0) {
            Console.noteln("");
            lastProgress = "";
         }
         Console.noteln(output.trim());
      }
   };

   process.onStandardErrorDataAvailable = function() {
      let err = this.stderr.toString();
      if (err && err.length > 0)
         Console.warningln(err.trim());
   };

   process.onStarted = function() {
      Console.noteln("Starting Prism CLI...");
      Console.noteln("Executable: " + exePath);
      Console.noteln("Arguments: " + args.join(" "));
   };

   process.onFinished = function() {
      if (lastProgress.length > 0) {
         Console.writeln("");
         lastProgress = "";
      }

      if (showedFinalizeMessage)
         Console.noteln("Prism stitching/export phase finished.");

      Console.noteln("Prism CLI finished.");
   };

   process.onError = function(code) {
      Console.warningln("ExternalProcess reported: " + code + " (ignored, waiting for output file)");
   };

   try {
      process.start(exePath, args);
   } catch (e) {
      Console.warningln("process.start reported an exception: " + e.message + " (ignored, waiting for output file)");
   }

   try {
      let spinStart = (new Date()).getTime();
      while (process.isStarting && ((new Date()).getTime() - spinStart) < 5000)
         processEvents();
   } catch (e) {
   }

   try {
      let runStart = (new Date()).getTime();
      while (process.isRunning && ((new Date()).getTime() - runStart) < 5000)
         processEvents();
   } catch (e) {
   }

   let timeoutMinutes = Math.max(1, outputTimeoutMinutes || 20);
   let timeoutMs = timeoutMinutes * 60 * 1000;

   if (!waitForFile(expectedOutputFilePath, timeoutMs))
      throw new Error("Prism output file was not found before timeout (" + timeoutMinutes + " minutes).");
}

// ----------------------------------------------------------------------------
// Dialog
// ----------------------------------------------------------------------------

function SyQonPrismDialog() {
   this.__base__ = Dialog;
   this.__base__();

   console.hide();
   SyQonPrismParameters.load();

   this.title = new Label(this);
   this.title.text = "SyQon Prism CLI";
   this.title.textAlignment = TextAlign_Center;

   this.description = new TextBox(this);
   this.description.readOnly = true;
   this.description.text =
      "This script integrates with the SyQon Prism CLI application.\n\n" +
      "Prism CLI download:\n" +
      "www.syqon.it/prism\n\n" +
      "Use the wrench button to select the Prism executable file itself.\n\n" +
      "The script saves the selected image as a temporary FITS file, runs Prism headlessly, " +
      "imports the denoised result as a temporary image, and then uses PixelMath to overwrite " +
      "the current target view so the original view name remains unchanged.\n\n" +
      "Options exposed here map directly to the CLI: model, tile size, overlap, pad, strength, " +
      "temporary stretch, AMP, CPU fallback, DirectML disable, and output timeout.";
   this.description.setMinWidth(520);
   this.description.setMinHeight(240);

   // Image selection
   this.imageSelectionLabel = new Label(this);
   this.imageSelectionLabel.text = "Select Image:";
   this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.imageSelectionDropdown = new ComboBox(this);
   this.imageSelectionDropdown.editEnabled = false;

   let windows = ImageWindow.windows;
   let activeWindowId = getActiveWindowIdSafe();

   for (let i = 0; i < windows.length; ++i) {
      this.imageSelectionDropdown.addItem(windows[i].mainView.id);
      if (windows[i].mainView.id == activeWindowId)
         this.imageSelectionDropdown.currentItem = i;
   }

   this.imageSelectionSizer = new HorizontalSizer;
   this.imageSelectionSizer.spacing = 4;
   this.imageSelectionSizer.add(this.imageSelectionLabel);
   this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

   // Model kind
   this.modelKindLabel = new Label(this);
   this.modelKindLabel.text = "Model:";
   this.modelKindLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.modelKindCombo = new ComboBox(this);
   this.modelKindCombo.addItem("prism_mini");
   this.modelKindCombo.addItem("prism_deep");

   let modelIndex = 1;
   if (SyQonPrismParameters.modelKind == "prism_mini")
      modelIndex = 0;
   this.modelKindCombo.currentItem = modelIndex;

   SyQonPrismParameters.modelKind = this.modelKindCombo.itemText(this.modelKindCombo.currentItem);

   this.modelKindCombo.onItemSelected = function(index) {
      SyQonPrismParameters.modelKind = this.itemText(index);
   };

   this.modelKindSizer = new HorizontalSizer;
   this.modelKindSizer.spacing = 4;
   this.modelKindSizer.add(this.modelKindLabel);
   this.modelKindSizer.add(this.modelKindCombo, 100);

   // Tile size
   this.tileLabel = new Label(this);
   this.tileLabel.text = "Tile Size:";
   this.tileLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.tileSpin = new SpinBox(this);
   this.tileSpin.minValue = 128;
   this.tileSpin.maxValue = 2048;
   this.tileSpin.stepSize = 64;
   this.tileSpin.value = SyQonPrismParameters.tileSize;
   this.tileSpin.onValueUpdated = function(value) {
      SyQonPrismParameters.tileSize = value;
   };

   this.tileSizer = new HorizontalSizer;
   this.tileSizer.spacing = 4;
   this.tileSizer.add(this.tileLabel);
   this.tileSizer.add(this.tileSpin);
   this.tileSizer.addStretch();

   // Overlap
   this.overlapLabel = new Label(this);
   this.overlapLabel.text = "Overlap:";
   this.overlapLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.overlapSpin = new SpinBox(this);
   this.overlapSpin.minValue = 8;
   this.overlapSpin.maxValue = 512;
   this.overlapSpin.stepSize = 8;
   this.overlapSpin.value = SyQonPrismParameters.overlap;
   this.overlapSpin.onValueUpdated = function(value) {
      SyQonPrismParameters.overlap = value;
   };

   this.overlapSizer = new HorizontalSizer;
   this.overlapSizer.spacing = 4;
   this.overlapSizer.add(this.overlapLabel);
   this.overlapSizer.add(this.overlapSpin);
   this.overlapSizer.addStretch();

   // Pad
   this.padLabel = new Label(this);
   this.padLabel.text = "Pad:";
   this.padLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.padSpin = new SpinBox(this);
   this.padSpin.minValue = 0;
   this.padSpin.maxValue = 2048;
   this.padSpin.stepSize = 8;
   this.padSpin.value = SyQonPrismParameters.pad;
   this.padSpin.onValueUpdated = function(value) {
      SyQonPrismParameters.pad = value;
   };

   this.padSizer = new HorizontalSizer;
   this.padSizer.spacing = 4;
   this.padSizer.add(this.padLabel);
   this.padSizer.add(this.padSpin);
   this.padSizer.addStretch();

   // Strength
   this.strengthLabel = new Label(this);
   this.strengthLabel.text = "Strength:";
   this.strengthLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.strengthSpin = new NumericControl(this);
   this.strengthSpin.label.text = "";
   this.strengthSpin.setRange(0.0, 1.0);
   this.strengthSpin.slider.setRange(0, 100);
   this.strengthSpin.setPrecision(2);
   this.strengthSpin.setValue(SyQonPrismParameters.strength);
   this.strengthSpin.onValueUpdated = function(value) {
      SyQonPrismParameters.strength = value;
   };

   this.strengthSizer = new HorizontalSizer;
   this.strengthSizer.spacing = 4;
   this.strengthSizer.add(this.strengthLabel);
   this.strengthSizer.add(this.strengthSpin, 100);

   // Temp stretch
   this.useMTFCheckbox = new CheckBox(this);
   this.useMTFCheckbox.text = "Use Temp Stretch";
   this.useMTFCheckbox.checked = SyQonPrismParameters.useMTF;
   this.useMTFCheckbox.toolTip = "Uses Prism temporary stretch / destretch pipeline (recommended for linear data).";
   this.useMTFCheckbox.onCheck = function(checked) {
      SyQonPrismParameters.useMTF = checked;
      this.dialog.mtfTargetSpin.enabled = checked;
   };

   // MTF target
   this.mtfTargetLabel = new Label(this);
   this.mtfTargetLabel.text = "MTF Target:";
   this.mtfTargetLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.mtfTargetSpin = new NumericControl(this);
   this.mtfTargetSpin.label.text = "";
   this.mtfTargetSpin.setRange(0.01, 0.50);
   this.mtfTargetSpin.slider.setRange(1, 50);
   this.mtfTargetSpin.setPrecision(3);
   this.mtfTargetSpin.setValue(SyQonPrismParameters.mtfTarget);
   this.mtfTargetSpin.enabled = SyQonPrismParameters.useMTF;
   this.mtfTargetSpin.onValueUpdated = function(value) {
      SyQonPrismParameters.mtfTarget = value;
   };

   this.mtfTargetSizer = new HorizontalSizer;
   this.mtfTargetSizer.spacing = 4;
   this.mtfTargetSizer.add(this.mtfTargetLabel);
   this.mtfTargetSizer.add(this.mtfTargetSpin, 100);

   // AMP
   this.useAMPCheckbox = new CheckBox(this);
   this.useAMPCheckbox.text = "Use AMP";
   this.useAMPCheckbox.checked = SyQonPrismParameters.useAMP;
   this.useAMPCheckbox.toolTip = "Use mixed precision where supported.";
   this.useAMPCheckbox.onCheck = function(checked) {
      SyQonPrismParameters.useAMP = checked;
      this.dialog.ampDTypeCombo.enabled = checked;
   };

   // AMP dtype
   this.ampDTypeLabel = new Label(this);
   this.ampDTypeLabel.text = "AMP Type:";
   this.ampDTypeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.ampDTypeCombo = new ComboBox(this);
   this.ampDTypeCombo.addItem("fp16");
   this.ampDTypeCombo.addItem("bf16");

   let ampIndex = 0;
   if (SyQonPrismParameters.ampDType == "bf16")
      ampIndex = 1;
   this.ampDTypeCombo.currentItem = ampIndex;
   this.ampDTypeCombo.enabled = SyQonPrismParameters.useAMP;

   SyQonPrismParameters.ampDType = this.ampDTypeCombo.itemText(this.ampDTypeCombo.currentItem);

   this.ampDTypeCombo.onItemSelected = function(index) {
      SyQonPrismParameters.ampDType = this.itemText(index);
   };

   this.ampSizer = new HorizontalSizer;
   this.ampSizer.spacing = 4;
   this.ampSizer.add(this.ampDTypeLabel);
   this.ampSizer.add(this.ampDTypeCombo, 100);

   // CPU
   this.useCPUCheckbox = new CheckBox(this);
   this.useCPUCheckbox.text = "Force CPU";
   this.useCPUCheckbox.checked = SyQonPrismParameters.useCPU;
   this.useCPUCheckbox.toolTip = "Force CPU inference.";
   this.useCPUCheckbox.onCheck = function(checked) {
      SyQonPrismParameters.useCPU = checked;
   };

   // No DML
   this.noDMLCheckbox = new CheckBox(this);
   this.noDMLCheckbox.text = "Disable DirectML";
   this.noDMLCheckbox.checked = SyQonPrismParameters.noDML;
   this.noDMLCheckbox.toolTip = "Disable DirectML preference on Windows.";
   this.noDMLCheckbox.onCheck = function(checked) {
      SyQonPrismParameters.noDML = checked;
   };

   // Output timeout
   this.outputTimeoutLabel = new Label(this);
   this.outputTimeoutLabel.text = "Output Timeout (min):";
   this.outputTimeoutLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.outputTimeoutSpin = new SpinBox(this);
   this.outputTimeoutSpin.minValue = 1;
   this.outputTimeoutSpin.maxValue = 240;
   this.outputTimeoutSpin.stepSize = 1;
   this.outputTimeoutSpin.value = SyQonPrismParameters.outputTimeoutMinutes;
   this.outputTimeoutSpin.toolTip = "Maximum time to wait for the Prism output file before aborting.";
   this.outputTimeoutSpin.onValueUpdated = function(value) {
      SyQonPrismParameters.outputTimeoutMinutes = value;
   };

   this.outputTimeoutSizer = new HorizontalSizer;
   this.outputTimeoutSizer.spacing = 4;
   this.outputTimeoutSizer.add(this.outputTimeoutLabel);
   this.outputTimeoutSizer.add(this.outputTimeoutSpin);
   this.outputTimeoutSizer.addStretch();

   // Setup button
   this.setupButton = new ToolButton(this);
   this.setupButton.icon = this.scaledResource(":/icons/wrench.png");
   this.setupButton.setScaledFixedSize(24, 24);
   this.setupButton.toolTip = "Select the Prism executable file.";
   this.setupButton.onClick = function() {
      let ofd = new OpenFileDialog;
      ofd.caption = "Select Prism Executable";
      if (SyQonPrismParameters.prismExePath.length > 0)
         ofd.initialPath = SyQonPrismParameters.prismExePath;
      ofd.multipleSelections = false;

      if (IS_WINDOWS)
         ofd.filters = [ ["Executable Files", "*.exe"], ["All Files", "*"] ];
      else
         ofd.filters = [ ["All Files", "*"] ];

      if (ofd.execute()) {
         SyQonPrismParameters.prismExePath = ofd.fileName;
         SyQonPrismParameters.save();
         this.dialog.exePathLabel.text = SyQonPrismParameters.prismExePath;
      }
   };

   this.exePathLabel = new TextBox(this);
   this.exePathLabel.readOnly = true;
   this.exePathLabel.setMinWidth(520);
   this.exePathLabel.setFixedHeight(50);
   this.exePathLabel.text =
      SyQonPrismParameters.prismExePath.length > 0
         ? SyQonPrismParameters.prismExePath
         : "No Prism executable selected.";

   // Buttons
   this.okButton = new PushButton(this);
   this.okButton.text = "OK";
   this.okButton.onClick = function() { this.dialog.ok(); };

   this.cancelButton = new PushButton(this);
   this.cancelButton.text = "Cancel";
   this.cancelButton.onClick = function() { this.dialog.cancel(); };

   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "Save a new instance of this script";
   this.newInstanceButton.onMousePress = function() {
      this.dialog.newInstance();
   };

   this.buttonsSizer = new HorizontalSizer;
   this.buttonsSizer.spacing = 6;
   this.buttonsSizer.add(this.newInstanceButton);
   this.buttonsSizer.addStretch();
   this.buttonsSizer.add(this.okButton);
   this.buttonsSizer.add(this.cancelButton);
   this.buttonsSizer.addStretch();

   // Layout
   this.sizer = new VerticalSizer;
   this.sizer.margin = 6;
   this.sizer.spacing = 6;
   this.sizer.addStretch();
   this.sizer.add(this.title);
   this.sizer.add(this.description);
   this.sizer.addSpacing(8);
   this.sizer.add(this.imageSelectionSizer);
   this.sizer.add(this.modelKindSizer);
   this.sizer.add(this.tileSizer);
   this.sizer.add(this.overlapSizer);
   this.sizer.add(this.padSizer);
   this.sizer.add(this.strengthSizer);
   this.sizer.add(this.useMTFCheckbox);
   this.sizer.add(this.mtfTargetSizer);
   this.sizer.add(this.useAMPCheckbox);
   this.sizer.add(this.ampSizer);
   this.sizer.add(this.useCPUCheckbox);
   this.sizer.add(this.noDMLCheckbox);
   this.sizer.add(this.outputTimeoutSizer);
   this.sizer.add(this.setupButton);
   this.sizer.add(this.exePathLabel);
   this.sizer.addSpacing(12);
   this.sizer.add(this.buttonsSizer);

   this.windowTitle = "SyQon Prism CLI";
   this.adjustToContents();
}
SyQonPrismDialog.prototype = new Dialog;

// ----------------------------------------------------------------------------
// Main
// ----------------------------------------------------------------------------

let dialog = new SyQonPrismDialog();

console.show();
Console.criticalln(" ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗");
Console.criticalln(" ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║");
Console.criticalln(" ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║");
Console.warningln(" ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║");
Console.warningln(" ███████║   ██║   ╚██████╔╝╚█████╔╝ ██║ ╚████║");
Console.warningln(" ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝");
Console.noteln    ("Starting SyQon ★ P R I S M ★  " + VERSION);
console.flush();

if (dialog.execute()) {
   let tempInputFilePath = "";
   let tempOutputFilePath = "";
   let tempJsonInfoPath = "";

   try {
      SyQonPrismParameters.save();

      if (SyQonPrismParameters.overlap >= SyQonPrismParameters.tileSize)
         throw new Error("Overlap must be smaller than tile size.");

      if (SyQonPrismParameters.prismExePath.length == 0)
         throw new Error("Please select the Prism executable with the wrench button.");

      if (!validatePrismExecutable(SyQonPrismParameters.prismExePath))
         throw new Error("Selected Prism executable does not exist.");

      let selectedIndex = dialog.imageSelectionDropdown.currentItem;
      let selectedWindow = ImageWindow.windows[selectedIndex];
      if (!selectedWindow)
         throw new Error("Please select an image.");

      let baseName = selectedWindow.mainView.id;
      let runPaths = buildRunPaths(baseName);

      tempInputFilePath = runPaths.inputFilePath;
      tempOutputFilePath = runPaths.outputFilePath;
      tempJsonInfoPath = runPaths.jsonInfoPath;

      saveImageAsFits(tempInputFilePath, selectedWindow);

      let args = buildPrismArgs(
         tempInputFilePath,
         tempOutputFilePath,
         tempJsonInfoPath
      );

      let exePath = SyQonPrismParameters.prismExePath;

      runPrismProcess(
         exePath,
         args,
         tempOutputFilePath,
         SyQonPrismParameters.outputTimeoutMinutes
      );
      processPrismOutput(tempOutputFilePath, selectedWindow);

      if (File.exists(tempJsonInfoPath)) {
         try {
            let lines = File.readLines(tempJsonInfoPath);
            if (lines.length > 0)
               console.noteln("Prism info JSON saved: " + tempJsonInfoPath);
         } catch (e) {
         }
      }

      console.writeln("Prism processing complete.");
   } catch (error) {
      console.criticalln("SyQon Prism CLI failed: " + error.message);
   } finally {
      if (tempInputFilePath.length > 0)
         deleteFileIfExists(tempInputFilePath);

      if (tempOutputFilePath.length > 0)
         deleteFileIfExists(tempOutputFilePath);

      if (tempJsonInfoPath.length > 0)
         deleteFileIfExists(tempJsonInfoPath);
   }
}
