#feature-id SyQonParallax : SyQon > Parallax
#feature-icon  syqonparallax.svg
#feature-info This script integrates with the SyQon Parallax CLI application for aberration correction, star reduction, and sharpening.

/****************************************************************************
 * ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗
 * ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║
 * ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║
 * ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║
 * ███████║   ██║   ╚██████╔╝╚█████╔╝ ██║ ╚████║
 * ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝
 *      ★  P A R A L L A X  ★
 *
 * SyQon Parallax CLI PixInsight Integration
 * Version: v1.5
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script integrates with the SyQon Parallax CLI application.
 * It saves the current image as a temporary FITS file, runs parallax_cli
 * headlessly with the selected options, and then imports the result
 * back into the target image.
 *
 * Pipeline order: Aberration Correction → Star Reduction → Sharpening
 * PI-side temp stretch is applied before sending and reversed after import.
 *
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>

#define VERSION "v1.5"

// ----------------------------------------------------------------------------
// Platform helpers
// ----------------------------------------------------------------------------

let IS_WINDOWS = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows");
let IS_MACOS   = (CoreApplication.platform == "MACOSX"   || CoreApplication.platform == "macOS");
let IS_LINUX   = (CoreApplication.platform == "Linux");

if (!IS_WINDOWS && !IS_MACOS && !IS_LINUX)
   console.criticalln("Unsupported platform: " + CoreApplication.platform);

let pathSeparator = IS_WINDOWS ? "\\" : "/";

// ----------------------------------------------------------------------------
// Temp/config paths
// ----------------------------------------------------------------------------

let scriptTempDir         = File.systemTempDirectory + pathSeparator + "SyQonParallaxCLI";
let syqonParallaxConfigFile = scriptTempDir + pathSeparator + "syqon_parallax_config.csv";

if (!File.directoryExists(scriptTempDir))
   File.createDirectory(scriptTempDir);

// ----------------------------------------------------------------------------
// Parameters
// ----------------------------------------------------------------------------

var SyQonParallaxParameters = {
   targetView:            undefined,
   targetViewId:          "",
   parallaxExePath:       "",

   // Stages
   correctAberration:     true,
   starReduction:         3,       // 0 = disabled, 1-6 = level
   sharpen:               0.8,     // 0.0 = disabled, 0.0-1.0 = alpha
   mode:                  "classic", // "classic" (Natural) or "aesthetics" (Defined)

   // Tiling
   tileSize:              512,
   overlap:               128,
   pad:                   512,

   // Stretch
   useMTF:                true,
   mtfTarget:             0.12,
   linkedStretch:         false,

   // Hardware
   useCPU:                false,
   noDML:                 false,

   // Misc
   outputTimeoutMinutes:  20,
   openDialogBox:         true,

   save: function() {
      Parameters.set("targetViewId",           this.targetViewId);
      Parameters.set("parallaxExePath",        this.parallaxExePath);
      Parameters.set("correctAberration",      this.correctAberration);
      Parameters.set("starReduction",          this.starReduction);
      Parameters.set("sharpen",                this.sharpen);
      Parameters.set("mode",                   this.mode);
      Parameters.set("tileSize",               this.tileSize);
      Parameters.set("overlap",                this.overlap);
      Parameters.set("pad",                    this.pad);
      Parameters.set("useMTF",                 this.useMTF);
      Parameters.set("mtfTarget",              this.mtfTarget);
      Parameters.set("linkedStretch",          this.linkedStretch);
      Parameters.set("useCPU",                 this.useCPU);
      Parameters.set("noDML",                  this.noDML);
      Parameters.set("outputTimeoutMinutes",   this.outputTimeoutMinutes);
      Parameters.set("openDialogBox",          this.openDialogBox);
      this.savePathToFile();
   },

   load: function() {
      if (Parameters.has("targetViewId"))
         this.targetViewId = Parameters.getString("targetViewId");
      if (Parameters.has("parallaxExePath"))
         this.parallaxExePath = Parameters.getString("parallaxExePath");
      if (Parameters.has("correctAberration"))
         this.correctAberration = Parameters.getBoolean("correctAberration");
      if (Parameters.has("starReduction"))
         this.starReduction = Parameters.getInteger("starReduction");
      if (Parameters.has("sharpen"))
         this.sharpen = Parameters.getReal("sharpen");
      if (Parameters.has("mode"))
         this.mode = Parameters.getString("mode");
      if (Parameters.has("tileSize"))
         this.tileSize = Parameters.getInteger("tileSize");
      if (Parameters.has("overlap"))
         this.overlap = Parameters.getInteger("overlap");
      if (Parameters.has("pad"))
         this.pad = Parameters.getInteger("pad");
      if (Parameters.has("useMTF"))
         this.useMTF = Parameters.getBoolean("useMTF");
      if (Parameters.has("mtfTarget"))
         this.mtfTarget = Parameters.getReal("mtfTarget");
      if (Parameters.has("linkedStretch"))
         this.linkedStretch = Parameters.getBoolean("linkedStretch");
      if (Parameters.has("useCPU"))
         this.useCPU = Parameters.getBoolean("useCPU");
      if (Parameters.has("noDML"))
         this.noDML = Parameters.getBoolean("noDML");
      if (Parameters.has("outputTimeoutMinutes"))
         this.outputTimeoutMinutes = Parameters.getInteger("outputTimeoutMinutes");
      if (Parameters.has("openDialogBox"))
         this.openDialogBox = Parameters.getBoolean("openDialogBox");

      this.loadPathFromFile();

      this.targetView = undefined;
      if (this.targetViewId && this.targetViewId.length > 0) {
         let w = ImageWindow.windowById(this.targetViewId);
         if (w && !w.isNull)
            this.targetView = w.mainView;
      }

      if (Parameters.isViewTarget && Parameters.targetView) {
         this.targetView   = Parameters.targetView;
         this.targetViewId = Parameters.targetView.id;
      }
   },

   savePathToFile: function() {
      try {
         let file = new File;
         file.createForWriting(syqonParallaxConfigFile);
         file.outTextLn(this.parallaxExePath);
         file.close();
      } catch (error) {
         console.warningln("Failed to save Parallax executable path: " + error.message);
      }
   },

   loadPathFromFile: function() {
      try {
         if (File.exists(syqonParallaxConfigFile)) {
            let lines = File.readLines(syqonParallaxConfigFile);
            if (lines.length > 0 && (!this.parallaxExePath || this.parallaxExePath.length == 0))
               this.parallaxExePath = lines[0].trim();
         }
      } catch (error) {
         console.warningln("Failed to load Parallax executable path: " + error.message);
      }
   }
};

// ----------------------------------------------------------------------------
// Utility helpers
// ----------------------------------------------------------------------------

function resolveWindowFromViewId(viewId) {
   if (!viewId || viewId.length == 0) return null;
   let w = ImageWindow.windowById(viewId);
   if (w && !w.isNull) return w;
   return null;
}

function getSelectedWindowFromDialog(dialog) {
   if (!dialog) return null;
   let idx = dialog.imageSelectionDropdown.currentItem;
   if (idx < 0 || idx >= dialog._windowIds.length) return null;
   return resolveWindowFromViewId(dialog._windowIds[idx]);
}

function validateParallaxExecutable(exePath) {
   if (!exePath || exePath.length == 0) return false;
   return File.exists(exePath);
}

function sanitizeFileName(name) {
   return name.replace(/[^A-Za-z0-9_\-]/g, "_");
}

function deleteFileIfExists(filePath) {
   try {
      if (File.exists(filePath)) {
         File.remove(filePath);
         console.writeln("Deleted file: " + filePath);
      }
   } catch (error) {
      console.warningln("Failed to delete file: " + filePath + " -> " + error.message);
   }
}

function getActiveWindowIdSafe() {
   try { return ImageWindow.activeWindow.mainView.id; }
   catch (e) { return ""; }
}

function ensureTempDirExists() {
   if (!File.directoryExists(scriptTempDir))
      File.createDirectory(scriptTempDir);
}

function buildRunPaths(baseName) {
   ensureTempDirExists();
   let runTag   = String((new Date()).getTime());
   let safeBase = sanitizeFileName(baseName);
   return {
      inputFilePath:  scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_input.fits",
      outputFilePath: scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_parallax.fits",
      jsonInfoPath:   scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_parallax.json"
   };
}

// ----------------------------------------------------------------------------
// PI-side temp stretch / destretch
// ----------------------------------------------------------------------------

function cloneWindowForProcessing(sourceWindow, newId) {
   let src = sourceWindow.mainView.image;
   let w = new ImageWindow(
      src.width, src.height, src.numberOfChannels,
      src.bitsPerSample, src.sampleType == SampleType_Real,
      src.isColor, newId
   );
   w.mainView.beginProcess(UndoFlag_NoSwapFile);
   w.mainView.image.assign(src);
   w.mainView.endProcess();
   return w;
}

function makeUniqueViewId(baseId) {
   return sanitizeFileName(baseId) + "_" + String((new Date()).getTime());
}

function applyPixelMathToView(view, expr, symbols) {
   let pm = new PixelMath;
   pm.useSingleExpression      = true;
   pm.expression               = expr;
   pm.symbols                  = symbols || "";
   pm.clearImageCacheAndExit   = false;
   pm.cacheGeneratedImages     = false;
   pm.generateOutput           = true;
   pm.singleThreaded           = false;
   pm.optimization             = true;
   pm.use64BitWorkingImage     = true;
   pm.rescale                  = false;
   pm.rescaleLower             = 0;
   pm.rescaleUpper             = 1;
   pm.truncate                 = true;
   pm.truncateLower            = 0;
   pm.truncateUpper            = 1;
   pm.createNewImage           = false;
   pm.showNewImage             = false;
   pm.newImageId               = "";
   pm.newImageWidth            = 0;
   pm.newImageHeight           = 0;
   pm.newImageAlpha            = false;
   pm.newImageColorSpace       = PixelMath.prototype.SameAsTarget;
   pm.newImageSampleFormat     = PixelMath.prototype.SameAsTarget;
   pm.executeOn(view);
}

// Per-channel unlinked PixelMath — matches Statistical Stretch's processUnlinkedColorImage pattern.
// expression = R channel, expression1 = G channel, expression2 = B channel.
// In each slot, $T refers to that channel's pixel value.
function applyPixelMathUnlinked(view, exprR, exprG, exprB) {
   let pm = new PixelMath;
   pm.useSingleExpression    = false;
   pm.expression             = exprR;
   pm.expression1            = exprG;
   pm.expression2            = exprB;
   pm.symbols                = "";
   pm.clearImageCacheAndExit = false;
   pm.cacheGeneratedImages   = false;
   pm.generateOutput         = true;
   pm.singleThreaded         = false;
   pm.optimization           = true;
   pm.use64BitWorkingImage   = true;
   pm.rescale                = false;
   pm.rescaleLower           = 0;
   pm.rescaleUpper           = 1;
   pm.truncate               = true;
   pm.truncateLower          = 0;
   pm.truncateUpper          = 1;
   pm.createNewImage         = false;
   pm.showNewImage           = false;
   pm.newImageId             = "";
   pm.newImageWidth          = 0;
   pm.newImageHeight         = 0;
   pm.newImageAlpha          = false;
   pm.newImageColorSpace     = PixelMath.prototype.SameAsTarget;
   pm.newImageSampleFormat   = PixelMath.prototype.SameAsTarget;
   pm.executeOn(view);
}

function createPIStretchedTempWindow(sourceWindow, targetMedian) {
   let tempId     = makeUniqueViewId(sourceWindow.mainView.id + "_ParallaxTemp");
   let tempWindow = cloneWindowForProcessing(sourceWindow, tempId);
   let img        = tempWindow.mainView.image;

   let stretchInfo = {
      used:           true,
      targetMedian:   targetMedian,
      wasColor:       img.isColor,
      originalMin:    [],
      originalMedian: []
   };

   let nChannels = img.isColor ? 3 : 1;
   for (let c = 0; c < nChannels; ++c)
      stretchInfo.originalMin.push(img.minimum(new Rect(0, 0, img.width, img.height), c, c));

   if (!img.isColor) {
      // ── Mono ──
      let mn = format("%.16f", stretchInfo.originalMin[0]);
      applyPixelMathToView(tempWindow.mainView,
         "($T-" + mn + ")/(1-" + mn + ")", "");

      let om = tempWindow.mainView.image.median();
      if (!isFinite(om) || om <= 0 || om >= 1)
         throw new Error("Invalid normalized median: " + om);
      stretchInfo.originalMedian.push(om);

      let omStr = format("%.16f", om);
      let tmStr = format("%.16f", targetMedian);
      applyPixelMathToView(tempWindow.mainView,
         "((" + omStr + "-1)*" + tmStr + "*$T)/(" +
         omStr + "*(" + tmStr + "+$T-1)-" + tmStr + "*$T)", "");

   } else if (SyQonParallaxParameters.linkedStretch) {
      // ── Color linked: single blackpoint + single median across all channels ──
      // Matches stretch_color_image(linked=True, no_black_clip=True)
      let allMin = Math.min(
         stretchInfo.originalMin[0],
         stretchInfo.originalMin[1],
         stretchInfo.originalMin[2]
      );
      let mn = format("%.16f", allMin);

      // Step 1: subtract single blackpoint from all channels
      applyPixelMathToView(tempWindow.mainView,
         "($T-" + mn + ")/(1-" + mn + ")", "");

      // Step 2: measure median as avg of per-channel medians
      let normImg = tempWindow.mainView.image;
      let om0 = normImg.median(new Rect(0, 0, normImg.width, normImg.height), 0, 0);
      let om1 = normImg.median(new Rect(0, 0, normImg.width, normImg.height), 1, 1);
      let om2 = normImg.median(new Rect(0, 0, normImg.width, normImg.height), 2, 2);
      let om = (om0 + om1 + om2) / 3.0;
      if (!isFinite(om) || om <= 0 || om >= 1)
         throw new Error("Invalid normalized median: " + om);
      stretchInfo.originalMedian.push(om);
      stretchInfo.originalMedian.push(om);
      stretchInfo.originalMedian.push(om);
      stretchInfo.originalMin[0] = allMin;
      stretchInfo.originalMin[1] = allMin;
      stretchInfo.originalMin[2] = allMin;

      // Step 3: single median transfer stretch applied to all channels
      let omStr = format("%.16f", om);
      let tm    = format("%.16f", targetMedian);
      applyPixelMathToView(tempWindow.mainView,
         "((" + omStr + "-1)*" + tm + "*$T)/(" +
         omStr + "*(" + tm + "+$T-1)-" + tm + "*$T)", "");

   } else {
      // ── Color: per-channel using expression/expression1/expression2 ──
      let mn0 = format("%.16f", stretchInfo.originalMin[0]);
      let mn1 = format("%.16f", stretchInfo.originalMin[1]);
      let mn2 = format("%.16f", stretchInfo.originalMin[2]);

      // Step 1: per-channel blackpoint normalization
      applyPixelMathUnlinked(tempWindow.mainView,
         "($T-" + mn0 + ")/(1-" + mn0 + ")",
         "($T-" + mn1 + ")/(1-" + mn1 + ")",
         "($T-" + mn2 + ")/(1-" + mn2 + ")");

      // Step 2: measure per-channel median after normalization
      let normImg = tempWindow.mainView.image;
      for (let c = 0; c < 3; ++c) {
         let om = normImg.median(new Rect(0, 0, normImg.width, normImg.height), c, c);
         if (!isFinite(om) || om <= 0 || om >= 1)
            throw new Error("Invalid normalized median for channel " + c + ": " + om);
         stretchInfo.originalMedian.push(om);
      }

      // Step 3: per-channel median transfer stretch
      let om0 = format("%.16f", stretchInfo.originalMedian[0]);
      let om1 = format("%.16f", stretchInfo.originalMedian[1]);
      let om2 = format("%.16f", stretchInfo.originalMedian[2]);
      let tm  = format("%.16f", targetMedian);

      applyPixelMathUnlinked(tempWindow.mainView,
         "((" + om0 + "-1)*" + tm + "*$T)/(" + om0 + "*(" + tm + "+$T-1)-" + tm + "*$T)",
         "((" + om1 + "-1)*" + tm + "*$T)/(" + om1 + "*(" + tm + "+$T-1)-" + tm + "*$T)",
         "((" + om2 + "-1)*" + tm + "*$T)/(" + om2 + "*(" + tm + "+$T-1)-" + tm + "*$T)");
   }

   return { tempWindow: tempWindow, stretchInfo: stretchInfo };
}

function reversePIStretchOnWindow(outputWindow, stretchInfo) {
   if (!stretchInfo || !stretchInfo.used) return;

   let tm = format("%.16f", stretchInfo.targetMedian);

   if (!stretchInfo.wasColor) {
      // ── Mono inverse ──
      let om = format("%.16f", stretchInfo.originalMedian[0]);
      let mn = format("%.16f", stretchInfo.originalMin[0]);
      applyPixelMathToView(outputWindow.mainView,
         "(" + om + "*$T*(" + tm + "-1))/(" +
         om + "*" + tm + " - " + om + "*$T + " + tm + "*$T - " + tm + ")", "");
      applyPixelMathToView(outputWindow.mainView,
         "($T*(1-" + mn + ")+" + mn + ")", "");
   } else {
      // ── Color: per-channel inverse using expression/expression1/expression2 ──
      let om0 = format("%.16f", stretchInfo.originalMedian[0]);
      let om1 = format("%.16f", stretchInfo.originalMedian[1]);
      let om2 = format("%.16f", stretchInfo.originalMedian[2]);
      let mn0 = format("%.16f", stretchInfo.originalMin[0]);
      let mn1 = format("%.16f", stretchInfo.originalMin[1]);
      let mn2 = format("%.16f", stretchInfo.originalMin[2]);

      // Inverse median transfer per channel
      applyPixelMathUnlinked(outputWindow.mainView,
         "(" + om0 + "*$T*(" + tm + "-1))/(" + om0 + "*" + tm + "-" + om0 + "*$T+" + tm + "*$T-" + tm + ")",
         "(" + om1 + "*$T*(" + tm + "-1))/(" + om1 + "*" + tm + "-" + om1 + "*$T+" + tm + "*$T-" + tm + ")",
         "(" + om2 + "*$T*(" + tm + "-1))/(" + om2 + "*" + tm + "-" + om2 + "*$T+" + tm + "*$T-" + tm + ")");

      // Inverse blackpoint normalization per channel
      applyPixelMathUnlinked(outputWindow.mainView,
         "($T*(1-" + mn0 + ")+" + mn0 + ")",
         "($T*(1-" + mn1 + ")+" + mn1 + ")",
         "($T*(1-" + mn2 + ")+" + mn2 + ")");
   }
}

// ----------------------------------------------------------------------------
// FITS save / load
// ----------------------------------------------------------------------------

function saveImageAsFits(filePath, view) {
   let imgWindow = view.isMainView ? view.window : view.mainView.window;
   if (!imgWindow)
      throw new Error("Image window is undefined for the specified view.");
   if (!imgWindow.saveAs(filePath, false, false, false, false))
      throw new Error("Failed to save image as FITS: " + filePath);
   console.writeln("Image saved as FITS: " + filePath);
}

function openFitsFile(filePath, label) {
   if (!File.exists(filePath))
      throw new Error(label + " file not found: " + filePath);
   let opened = ImageWindow.open(filePath);
   if (!opened || opened.length < 1)
      throw new Error("Failed to open " + label + " image: " + filePath);
   let w = opened[0];
   w.show();
   return w;
}

function overwriteTargetWithOutput(targetWindow, outputWindow) {
   let expr = outputWindow.mainView.id;
   // If original is mono but output opened as color, use channel 0
   if (!targetWindow.mainView.image.isColor && outputWindow.mainView.image.isColor)
      expr = outputWindow.mainView.id + "[0]";

   let pm = new PixelMath;
   pm.useSingleExpression = true;
   pm.expression          = expr;
   pm.createNewImage      = false;
   pm.rescale             = false;
   pm.truncate            = false;
   pm.executeOn(targetWindow.mainView);
}

function processParallaxOutput(outputFilePath, targetWindow, stretchInfo) {
   let outputWindow = openFitsFile(outputFilePath, "Parallax");
   try {
      if (stretchInfo && stretchInfo.used) {
         console.noteln("Reversing PI temporary stretch on Parallax output...");
         reversePIStretchOnWindow(outputWindow, stretchInfo);
      }
      overwriteTargetWithOutput(targetWindow, outputWindow);
   } finally {
      outputWindow.forceClose();
      deleteFileIfExists(outputFilePath);
   }
}

// ----------------------------------------------------------------------------
// CLI argument construction
// ----------------------------------------------------------------------------

function buildParallaxArgs(inputFilePath, outputFilePath, jsonInfoPath) {
   let args = [];

   args.push("--i");
   args.push(inputFilePath);

   args.push("--o");
   args.push(outputFilePath);

   // Only pass --mode when non-default, so older parallax_cli builds that
   // don't know about the flag stay compatible.
   if (SyQonParallaxParameters.mode && SyQonParallaxParameters.mode != "classic") {
      args.push("--mode");
      args.push(SyQonParallaxParameters.mode);
   }

   if (SyQonParallaxParameters.correctAberration)
      args.push("--correct-aberration");

   if (SyQonParallaxParameters.starReduction > 0) {
      args.push("--star-reduction");
      args.push(String(SyQonParallaxParameters.starReduction));
   }

   if (SyQonParallaxParameters.sharpen > 0.0) {
      args.push("--sharpen");
      args.push(format("%.2f", SyQonParallaxParameters.sharpen));
   }

   args.push("--tile");
   args.push(String(SyQonParallaxParameters.tileSize));

   args.push("--overlap");
   args.push(String(SyQonParallaxParameters.overlap));

   args.push("--pad");
   args.push(String(SyQonParallaxParameters.pad));

   if (SyQonParallaxParameters.useCPU)
      args.push("--cpu");

   if (SyQonParallaxParameters.noDML)
      args.push("--no-dml");

   if (jsonInfoPath && jsonInfoPath.length > 0) {
      args.push("--json-info");
      args.push(jsonInfoPath);
   }

   return args;
}

// ----------------------------------------------------------------------------
// Main execution function
// ----------------------------------------------------------------------------

function executeParallaxOnWindow(targetWindow) {
   let tempInputFilePath  = "";
   let tempOutputFilePath = "";
   let tempJsonInfoPath   = "";
   let tempStretchWindow  = null;
   let stretchInfo        = { used: false };

   try {
      if (!targetWindow || targetWindow.isNull)
         throw new Error("No valid target image selected.");

      if (SyQonParallaxParameters.overlap >= SyQonParallaxParameters.tileSize)
         throw new Error("Overlap must be smaller than tile size.");

      if (!SyQonParallaxParameters.correctAberration &&
          SyQonParallaxParameters.starReduction == 0 &&
          SyQonParallaxParameters.sharpen <= 0.0)
         throw new Error("Please enable at least one processing stage.");

      if (SyQonParallaxParameters.parallaxExePath.length == 0)
         throw new Error("Please select the Parallax executable with the wrench button.");

      if (!validateParallaxExecutable(SyQonParallaxParameters.parallaxExePath))
         throw new Error("Selected Parallax executable does not exist.");

      SyQonParallaxParameters.targetView   = targetWindow.mainView;
      SyQonParallaxParameters.targetViewId = targetWindow.mainView.id;
      SyQonParallaxParameters.save();

      let baseName = targetWindow.mainView.id;
      let runPaths = buildRunPaths(baseName);

      tempInputFilePath  = runPaths.inputFilePath;
      tempOutputFilePath = runPaths.outputFilePath;
      tempJsonInfoPath   = runPaths.jsonInfoPath;

      let sourceForSave = targetWindow;

      if (SyQonParallaxParameters.useMTF) {
         console.noteln("Creating PI-side temporary stretch copy...");
         let stretched     = createPIStretchedTempWindow(targetWindow, SyQonParallaxParameters.mtfTarget);
         tempStretchWindow = stretched.tempWindow;
         stretchInfo       = stretched.stretchInfo;
         sourceForSave     = tempStretchWindow;
      }

      saveImageAsFits(tempInputFilePath, sourceForSave.mainView);

      let args = buildParallaxArgs(tempInputFilePath, tempOutputFilePath, tempJsonInfoPath);

      let controller = new ParallaxRunController(targetWindow, tempStretchWindow, stretchInfo, runPaths);

      // Ownership transfers to controller
      tempStretchWindow  = null;
      tempInputFilePath  = "";
      tempOutputFilePath = "";
      tempJsonInfoPath   = "";

      controller.start(SyQonParallaxParameters.parallaxExePath, args);

   } catch (error) {
      console.criticalln("SyQon Parallax CLI failed: " + error.message);
   } finally {
      if (tempStretchWindow && !tempStretchWindow.isNull) {
         try { tempStretchWindow.forceClose(); } catch (e) {}
      }
      if (tempInputFilePath.length  > 0) deleteFileIfExists(tempInputFilePath);
      if (tempOutputFilePath.length > 0) deleteFileIfExists(tempOutputFilePath);
      if (tempJsonInfoPath.length   > 0) deleteFileIfExists(tempJsonInfoPath);
   }
}

// ----------------------------------------------------------------------------
// Async run controller
// ----------------------------------------------------------------------------

function ParallaxRunController(targetWindow, tempStretchWindow, stretchInfo, runPaths) {
   this.targetWindow      = targetWindow;
   this.tempStretchWindow = tempStretchWindow;
   this.stretchInfo       = stretchInfo;
   this.runPaths          = runPaths;

   this.process      = new ExternalProcess;
   this.waitDialog   = null;
   this.timer        = null;

   this.startTime    = 0;
   this.timeoutMs    = Math.max(1, SyQonParallaxParameters.outputTimeoutMinutes || 20) * 60 * 1000;

   this.canceled     = false;
   this.completed    = false;
   this.cleaned      = false;
   this.processFinished = false;

   this.stdoutBuffer = "";
   this.stderrBuffer = "";
   this.lastStage    = "Starting Parallax CLI...";
   this.lastPercent  = -1;
}

ParallaxRunController.prototype.cleanupOnSuccess = function() {
   if (this.cleaned) return;
   this.cleaned = true;
   try {
      if (this.tempStretchWindow && !this.tempStretchWindow.isNull)
         this.tempStretchWindow.forceClose();
   } catch (e) {}
   deleteFileIfExists(this.runPaths.inputFilePath);
   deleteFileIfExists(this.runPaths.outputFilePath);
   deleteFileIfExists(this.runPaths.jsonInfoPath);
};

ParallaxRunController.prototype.cleanupOnCancel = function() {
   if (this.cleaned) return;
   this.cleaned = true;
   try {
      if (this.tempStretchWindow && !this.tempStretchWindow.isNull)
         this.tempStretchWindow.forceClose();
   } catch (e) {}
   // Do NOT delete output/json — CLI may still be writing them
};

ParallaxRunController.prototype.handleLine = function(line) {
   if (!line) return;
   let text = line.trim();
   if (text.length == 0) return;

   let tileMatch = text.match(/^\[\s*(\d+)%\]\s+(.*?)\s+\((\d+)\/(\d+)\)$/);
   if (tileMatch) {
      this.lastPercent = parseInt(tileMatch[1], 10);
      this.lastStage   = tileMatch[2] + " (" + tileMatch[3] + "/" + tileMatch[4] + ")";
      if (this.waitDialog)
         this.waitDialog.updateStatus(this.lastStage, this.lastPercent, this.startTime, this.timeoutMs);
      return;
   }

   this.lastStage = text;
   if (this.waitDialog)
      this.waitDialog.updateStatus(this.lastStage, this.lastPercent, this.startTime, this.timeoutMs);
   Console.noteln(text);
};

ParallaxRunController.prototype.processBufferedText = function(chunk, which) {
   if (!chunk || chunk.length == 0) return;

   if (which == "stdout") this.stdoutBuffer += chunk;
   else                   this.stderrBuffer += chunk;

   let buffer    = (which == "stdout") ? this.stdoutBuffer : this.stderrBuffer;
   let lines     = buffer.split(/\r?\n/);
   let remainder = lines.pop();

   for (let i = 0; i < lines.length; ++i)
      this.handleLine(lines[i]);

   if (which == "stdout") this.stdoutBuffer = remainder;
   else                   this.stderrBuffer = remainder;
};

ParallaxRunController.prototype.start = function(exePath, args) {
   let self = this;

   this.process.onStandardOutputDataAvailable = function() {
      self.processBufferedText(String(this.stdout), "stdout");
   };

   this.process.onStandardErrorDataAvailable = function() {
      self.processBufferedText(String(this.stderr), "stderr");
   };

   this.process.onStarted = function() {
      Console.noteln("Starting Parallax CLI...");
      Console.noteln("Executable: " + exePath);
      Console.noteln("Arguments: " + args.join(" "));
      self.lastStage = "Parallax CLI started...";
      if (self.waitDialog)
         self.waitDialog.updateStatus(self.lastStage, self.lastPercent, self.startTime, self.timeoutMs);
   };

   this.process.onFinished = function() {
      if (self.stdoutBuffer.length > 0) { self.handleLine(self.stdoutBuffer); self.stdoutBuffer = ""; }
      if (self.stderrBuffer.length > 0) { self.handleLine(self.stderrBuffer); self.stderrBuffer = ""; }
      self.processFinished = true;
      Console.noteln("Parallax CLI finished.");
   };

   this.process.onError = function(code) {
      Console.warningln("ExternalProcess reported: " + code + " (continuing to wait for output)");
   };

   this.startTime = (new Date()).getTime();

   this.waitDialog = new ParallaxWaitDialog(this);
   this.waitDialog.updateStatus("Launching Parallax CLI...", -1, this.startTime, this.timeoutMs);

   try {
      this.process.start(exePath, args);
   } catch (e) {
      throw new Error("Failed to start Parallax CLI: " + e.message);
   }

   this.startTimer();
   this.waitDialog.execute();
};

ParallaxRunController.prototype.startTimer = function() {
   let self        = this;
   this.timer          = new Timer;
   this.timer.interval = 0.5;
   this.timer.periodic = true;
   this.timer.onTimeout = function() { self.poll(); };
   this.timer.start();
};

ParallaxRunController.prototype.stopTimer = function() {
   try { if (this.timer) this.timer.stop(); } catch (e) {}
};

ParallaxRunController.prototype.poll = function() {
   if (this.canceled || this.completed) return;

   let now     = (new Date()).getTime();
   let elapsed = now - this.startTime;

   if (this.waitDialog)
      this.waitDialog.updateStatus(this.lastStage, this.lastPercent, this.startTime, this.timeoutMs);

   if (this.processFinished && File.exists(this.runPaths.outputFilePath)) {
      this.completed = true;
      this.stopTimer();

      let maxRetries = 10;
      let retryDelay = 3000;
      let lastError  = "";
      let succeeded  = false;

      for (let attempt = 0; attempt < maxRetries; ++attempt) {
         try { System.msleep(retryDelay); } catch (e) {}
         try {
            processParallaxOutput(this.runPaths.outputFilePath, this.targetWindow, this.stretchInfo);
            succeeded = true;
            break;
         } catch (e) {
            lastError = e.message;
            Console.warningln("Output not ready yet (attempt " + (attempt + 1) + "/" + maxRetries + "): " + lastError);
         }
      }

      if (succeeded) {
         if (File.exists(this.runPaths.jsonInfoPath))
            Console.noteln("Parallax info JSON saved: " + this.runPaths.jsonInfoPath);
         Console.writeln("Parallax processing complete on: " + this.targetWindow.mainView.id);
      } else {
         Console.criticalln("SyQon Parallax CLI failed while importing output: " + lastError);
      }

      this.cleanupOnSuccess();
      if (this.waitDialog) this.waitDialog.ok();
      return;
   }

   if (this.processFinished && !File.exists(this.runPaths.outputFilePath)) {
      this.completed = true;
      this.stopTimer();
      this.cleanupOnCancel();
      if (this.waitDialog) this.waitDialog.cancel();
      Console.criticalln("SyQon Parallax CLI failed: process exited without producing an output file. Check the log above for errors from parallax_cli.");
      return;
   }

   if (elapsed >= this.timeoutMs) {
      this.completed = true;
      this.stopTimer();
      this.cleanupOnCancel();
      if (this.waitDialog) this.waitDialog.cancel();
      Console.criticalln("SyQon Parallax CLI failed: output file was not found before timeout.");
      return;
   }
};

ParallaxRunController.prototype.cancelWaiting = function() {
   if (this.completed || this.canceled) return;
   this.canceled = true;
   this.stopTimer();
   this.cleanupOnCancel();
   Console.warningln("User canceled waiting for Parallax output. parallax_cli may still be running in the background.");
   if (this.waitDialog) this.waitDialog.cancel();
};

// ----------------------------------------------------------------------------
// Wait dialog
// ----------------------------------------------------------------------------

function formatElapsed(ms) {
   let s = Math.max(0, Math.floor(ms / 1000));
   let h = Math.floor(s / 3600); s -= h * 3600;
   let m = Math.floor(s / 60);   s -= m * 60;
   if (h > 0) return format("%d:%02d:%02d", h, m, s);
   return format("%02d:%02d", m, s);
}

function ParallaxWaitDialog(controller) {
   this.__base__ = Dialog;
   this.__base__();

   let self = this;
   this.controller    = controller;
   this.windowTitle   = "SyQon Parallax \u2014 Processing";
   this.userResizable = false;
   this.minWidth      = 560;

   this.waitHeaderLabel = new Label(this);
   this.waitHeaderLabel.useRichText   = true;
   this.waitHeaderLabel.textAlignment = TextAlign_Center;
   this.waitHeaderLabel.text =
      "<b><font size='+1'>\u2605 SyQon Parallax \u2605</font></b><br/>" +
      "<font size='-1'>Processing in progress...</font>";

   this.headerSep = new Frame(this);
   this.headerSep.frameStyle = FrameStyle_Box;
   this.headerSep.setFixedHeight(2);

   this.statusGroup       = new GroupBox(this);
   this.statusGroup.title = "Status";

   this.infoLabel = new Label(this);
   this.infoLabel.useRichText  = true;
   this.infoLabel.wordWrapping = true;
   this.infoLabel.text         = "<i>Waiting for Parallax output...</i>";

   this.progressLabel = new Label(this);
   this.progressLabel.useRichText = true;
   this.progressLabel.text        = "<b>Progress:</b> starting...";

   this.progressBarLabel = new Label(this);
   this.progressBarLabel.useRichText = false;
   this.progressBarLabel.text        = "";

   this.elapsedLabel = new Label(this);
   this.elapsedLabel.useRichText = true;
   this.elapsedLabel.text        = "<b>Elapsed:</b> 00:00";

   this.statusGroup.sizer = new VerticalSizer;
   this.statusGroup.sizer.margin  = 8;
   this.statusGroup.sizer.spacing = 6;
   this.statusGroup.sizer.add(this.infoLabel);
   this.statusGroup.sizer.add(this.progressLabel);
   this.statusGroup.sizer.add(this.progressBarLabel);
   this.statusGroup.sizer.add(this.elapsedLabel);

   this.noteLabel = new Label(this);
   this.noteLabel.useRichText  = true;
   this.noteLabel.wordWrapping = true;
   this.noteLabel.text =
      "<i>Cancel stops waiting and closes this script.<br/>" +
      "It does not terminate parallax_cli if it is already running.</i>";

   this.cancelButton = new PushButton(this);
   this.cancelButton.text    = "Cancel";
   this.cancelButton.onClick = function() { self.controller.cancelWaiting(); };

   this.sizer = new VerticalSizer;
   this.sizer.margin  = 12;
   this.sizer.spacing = 8;
   this.sizer.add(this.waitHeaderLabel);
   this.sizer.add(this.headerSep);
   this.sizer.addSpacing(4);
   this.sizer.add(this.statusGroup);
   this.sizer.addSpacing(4);
   this.sizer.add(this.noteLabel);
   this.sizer.addSpacing(8);

   this.buttonSizer = new HorizontalSizer;
   this.buttonSizer.addStretch();
   this.buttonSizer.add(this.cancelButton);
   this.buttonSizer.addStretch();
   this.sizer.add(this.buttonSizer);

   this.adjustToContents();
}
ParallaxWaitDialog.prototype = new Dialog;

ParallaxWaitDialog.prototype.updateStatus = function(stage, percent, startTime, timeoutMs) {
   let now     = (new Date()).getTime();
   let elapsed = now - startTime;
   let remain  = Math.max(0, timeoutMs - elapsed);

   this.infoLabel.text = "<i>Parallax is running...</i>";
   this.progressLabel.text =
      (percent >= 0)
         ? ("<b>Progress:</b> " + stage + "  [<b>" + percent + "%</b>]")
         : ("<b>Progress:</b> " + stage);

   if (percent >= 0) {
      let barLen = 40;
      let filled = Math.round(barLen * percent / 100);
      let bar = "";
      for (let i = 0; i < barLen; i++)
         bar += (i < filled) ? "\u2588" : "\u2591";
      this.progressBarLabel.text = bar + "  " + percent + "%";
   } else {
      this.progressBarLabel.text = "";
   }

   this.elapsedLabel.text =
      "<b>Elapsed:</b> " + formatElapsed(elapsed) +
      "    <b>Timeout in:</b> " + formatElapsed(remain);
};

// ----------------------------------------------------------------------------
// Main dialog
// ----------------------------------------------------------------------------

function SyQonParallaxDialog() {
   this.__base__ = Dialog;
   this.__base__();

   let self = this;
   SyQonParallaxParameters.load();
   this._windowIds = [];

   this.syncToParameters = function() {
      SyQonParallaxParameters.mode                   = (this.modeCombo.currentItem == 1) ? "aesthetics" : "classic";
      SyQonParallaxParameters.correctAberration      = this.correctAberrationCheckbox.checked;
      SyQonParallaxParameters.starReduction          = this.starReductionSpin.value;
      SyQonParallaxParameters.sharpen                = this.sharpenSpin.value;
      SyQonParallaxParameters.tileSize               = this.tileSpin.value;
      SyQonParallaxParameters.overlap                = this.overlapSpin.value;
      SyQonParallaxParameters.pad                    = this.padSpin.value;
      SyQonParallaxParameters.useMTF                 = this.useMTFCheckbox.checked;
      SyQonParallaxParameters.mtfTarget              = this.mtfTargetSpin.value;
      SyQonParallaxParameters.linkedStretch          = this.linkedStretchCheckbox.checked;
      SyQonParallaxParameters.useCPU                 = this.useCPUCheckbox.checked;
      SyQonParallaxParameters.noDML                  = this.noDMLCheckbox.checked;
      SyQonParallaxParameters.outputTimeoutMinutes   = this.outputTimeoutSpin.value;

      let w = getSelectedWindowFromDialog(this);
      if (w && !w.isNull) {
         SyQonParallaxParameters.targetView   = w.mainView;
         SyQonParallaxParameters.targetViewId = w.mainView.id;
      }
      SyQonParallaxParameters.save();
   };

   this.selectViewById = function(viewId) {
      if (!viewId || viewId.length == 0) return false;
      for (let i = 0; i < this._windowIds.length; ++i) {
         if (this._windowIds[i] == viewId) {
            this.imageSelectionDropdown.currentItem = i;
            return true;
         }
      }
      return false;
   };

   // ── Header ──
   this.headerLabel = new Label(this);
   this.headerLabel.useRichText   = true;
   this.headerLabel.textAlignment = TextAlign_Center;
   this.headerLabel.text =
      "<b><font size='+2'>\u2605 SyQon Parallax \u2605</font></b><br/>" +
      "<font size='-1'>Aberration Correction · Star Reduction · Sharpening</font><br/>" +
      "<b>" + VERSION + "</b>";

   this.headerSeparator = new Frame(this);
   this.headerSeparator.frameStyle = FrameStyle_Box;
   this.headerSeparator.setFixedHeight(2);

   // ── Image selection ──
   this.imageSelectionLabel = new Label(this);
   this.imageSelectionLabel.text          = "Target Image:";
   this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.imageSelectionDropdown = new ComboBox(this);
   this.imageSelectionDropdown.editEnabled = false;

   let windows        = ImageWindow.windows;
   let activeWindowId = getActiveWindowIdSafe();
   for (let i = 0; i < windows.length; ++i) {
      let wid = windows[i].mainView.id;
      this.imageSelectionDropdown.addItem(wid);
      this._windowIds.push(wid);
      if (wid == activeWindowId)
         this.imageSelectionDropdown.currentItem = i;
   }

   this.imageSelectionSizer = new HorizontalSizer;
   this.imageSelectionSizer.spacing = 4;
   this.imageSelectionSizer.add(this.imageSelectionLabel);
   this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

   // ── Model style ──
   this.modeLabel = new Label(this);
   this.modeLabel.text          = "Model Style:";
   this.modeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.modeCombo = new ComboBox(this);
   this.modeCombo.editEnabled = false;
   this.modeCombo.addItem("Natural");  // 0 -> classic
   this.modeCombo.addItem("Defined");  // 1 -> aesthetics
   this.modeCombo.currentItem =
      (SyQonParallaxParameters.mode == "aesthetics") ? 1 : 0;
   this.modeCombo.toolTip =
      "Natural: preserves the look of the input; subtler results.\n" +
      "Defined: bolder, more shaped results across all three stages.";
   this.modeCombo.onItemSelected = function(idx) {
      SyQonParallaxParameters.mode = (idx == 1) ? "aesthetics" : "classic";
   };

   this.modeSizer = new HorizontalSizer;
   this.modeSizer.spacing = 4;
   this.modeSizer.add(this.modeLabel);
   this.modeSizer.add(this.modeCombo, 100);

   // ── Correct Aberration ──
   this.correctAberrationCheckbox = new CheckBox(this);

   this.correctAberrationCheckbox.text    = "Correct Aberration";
   this.correctAberrationCheckbox.checked = SyQonParallaxParameters.correctAberration;
   this.correctAberrationCheckbox.toolTip = "Run the aberration correction model (boolean — on or off).";
   this.correctAberrationCheckbox.onCheck = function(checked) {
      SyQonParallaxParameters.correctAberration = checked;
   };

   // ── Star Reduction ──
   this.starReductionLabel = new Label(this);
   this.starReductionLabel.text          = "Star Reduction:";
   this.starReductionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.starReductionSpin = new SpinBox(this);
   this.starReductionSpin.minValue  = 0;
   this.starReductionSpin.maxValue  = 10;
   this.starReductionSpin.stepSize  = 1;
   this.starReductionSpin.value     = SyQonParallaxParameters.starReduction;
   this.starReductionSpin.toolTip   = "Star reduction level 1-10 (0 = disabled). 1 = minimal, 10 = aggressive.";
   this.starReductionSpin.onValueUpdated = function(value) {
      SyQonParallaxParameters.starReduction = value;
   };

   this.starReductionNoteLabel = new Label(this);
   this.starReductionNoteLabel.text          = "(0 = off)";
   this.starReductionNoteLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.starReductionSizer = new HorizontalSizer;
   this.starReductionSizer.spacing = 4;
   this.starReductionSizer.add(this.starReductionLabel);
   this.starReductionSizer.add(this.starReductionSpin);
   this.starReductionSizer.add(this.starReductionNoteLabel);
   this.starReductionSizer.addStretch();

   // ── Sharpen ──
   this.sharpenLabel = new Label(this);
   this.sharpenLabel.text          = "Sharpen:";
   this.sharpenLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.sharpenSpin = new NumericControl(this);
   this.sharpenSpin.label.text = "";
   this.sharpenSpin.setRange(0.0, 2.0);
   this.sharpenSpin.slider.setRange(0, 200);
   this.sharpenSpin.setPrecision(2);
   this.sharpenSpin.setValue(SyQonParallaxParameters.sharpen);
   this.sharpenSpin.toolTip = "Sharpening blend 0.0 (off) to 1.0 (full) to 2.0 (200%). Blends input with sharpened output.";
   this.sharpenSpin.onValueUpdated = function(value) {
      SyQonParallaxParameters.sharpen = value;
   };

   this.sharpenSizer = new HorizontalSizer;
   this.sharpenSizer.spacing = 4;
   this.sharpenSizer.add(this.sharpenLabel);
   this.sharpenSizer.add(this.sharpenSpin, 100);

   // ── Tile size ──
   this.tileLabel = new Label(this);
   this.tileLabel.text          = "Tile Size:";
   this.tileLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.tileSpin = new SpinBox(this);
   this.tileSpin.minValue = 128;
   this.tileSpin.maxValue = 2048;
   this.tileSpin.stepSize = 64;
   this.tileSpin.value    = SyQonParallaxParameters.tileSize;
   this.tileSpin.onValueUpdated = function(value) { SyQonParallaxParameters.tileSize = value; };

   this.tileSizer = new HorizontalSizer;
   this.tileSizer.spacing = 4;
   this.tileSizer.add(this.tileLabel);
   this.tileSizer.add(this.tileSpin);
   this.tileSizer.addStretch();

   // ── Overlap ──
   this.overlapLabel = new Label(this);
   this.overlapLabel.text          = "Overlap:";
   this.overlapLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.overlapSpin = new SpinBox(this);
   this.overlapSpin.minValue = 8;
   this.overlapSpin.maxValue = 512;
   this.overlapSpin.stepSize = 8;
   this.overlapSpin.value    = SyQonParallaxParameters.overlap;
   this.overlapSpin.onValueUpdated = function(value) { SyQonParallaxParameters.overlap = value; };

   this.overlapSizer = new HorizontalSizer;
   this.overlapSizer.spacing = 4;
   this.overlapSizer.add(this.overlapLabel);
   this.overlapSizer.add(this.overlapSpin);
   this.overlapSizer.addStretch();

   // ── Pad ──
   this.padLabel = new Label(this);
   this.padLabel.text          = "Pad:";
   this.padLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.padSpin = new SpinBox(this);
   this.padSpin.minValue = 0;
   this.padSpin.maxValue = 2048;
   this.padSpin.stepSize = 8;
   this.padSpin.value    = SyQonParallaxParameters.pad;
   this.padSpin.onValueUpdated = function(value) { SyQonParallaxParameters.pad = value; };

   this.padSizer = new HorizontalSizer;
   this.padSizer.spacing = 4;
   this.padSizer.add(this.padLabel);
   this.padSizer.add(this.padSpin);
   this.padSizer.addStretch();

   // ── Temp stretch ──
   this.useMTFCheckbox = new CheckBox(this);
   this.useMTFCheckbox.text    = "Use PI Temp Stretch";
   this.useMTFCheckbox.checked = SyQonParallaxParameters.useMTF;
   this.useMTFCheckbox.toolTip = "Applies a temporary stretch in PixInsight before sending to Parallax, then reverses it afterward. Recommended for linear data.";
   this.useMTFCheckbox.onCheck = function(checked) {
      SyQonParallaxParameters.useMTF = checked;
      self.mtfTargetSpin.enabled = checked;
   };

   this.mtfTargetLabel = new Label(this);
   this.mtfTargetLabel.text          = "MTF Target:";
   this.mtfTargetLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.mtfTargetSpin = new NumericControl(this);
   this.mtfTargetSpin.label.text = "";
   this.mtfTargetSpin.setRange(0.01, 0.50);
   this.mtfTargetSpin.slider.setRange(1, 50);
   this.mtfTargetSpin.setPrecision(3);
   this.mtfTargetSpin.setValue(SyQonParallaxParameters.mtfTarget);
   this.mtfTargetSpin.enabled = SyQonParallaxParameters.useMTF;
   this.mtfTargetSpin.onValueUpdated = function(value) { SyQonParallaxParameters.mtfTarget = value; };

   this.mtfTargetSizer = new HorizontalSizer;
   this.mtfTargetSizer.spacing = 4;
   this.mtfTargetSizer.add(this.mtfTargetLabel);
   this.mtfTargetSizer.add(this.mtfTargetSpin, 100);

   this.linkedStretchCheckbox = new CheckBox(this);
   this.linkedStretchCheckbox.text    = "Linked stretch (preserves star colors - use if already color calibrated)";
   this.linkedStretchCheckbox.checked = SyQonParallaxParameters.linkedStretch;
   this.linkedStretchCheckbox.toolTip = "Uses a single blackpoint and median across all channels.\nPrevents color shifts on bright stars. Try if stars turn yellow.";
   this.linkedStretchCheckbox.onCheck = function(checked) {
      SyQonParallaxParameters.linkedStretch = checked;
   };

   // ── CPU / DML ──
   this.useCPUCheckbox = new CheckBox(this);
   this.useCPUCheckbox.text    = "Force CPU";
   this.useCPUCheckbox.checked = SyQonParallaxParameters.useCPU;
   this.useCPUCheckbox.toolTip = "Force CPU inference.";
   this.useCPUCheckbox.onCheck = function(checked) { SyQonParallaxParameters.useCPU = checked; };

   this.noDMLCheckbox = new CheckBox(this);
   this.noDMLCheckbox.text    = "Disable DirectML";
   this.noDMLCheckbox.checked = SyQonParallaxParameters.noDML;
   this.noDMLCheckbox.toolTip = "Disable DirectML preference on Windows.";
   this.noDMLCheckbox.onCheck = function(checked) { SyQonParallaxParameters.noDML = checked; };

   // ── Output timeout ──
   this.outputTimeoutLabel = new Label(this);
   this.outputTimeoutLabel.text          = "Output Timeout (min):";
   this.outputTimeoutLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.outputTimeoutSpin = new SpinBox(this);
   this.outputTimeoutSpin.minValue  = 1;
   this.outputTimeoutSpin.maxValue  = 240;
   this.outputTimeoutSpin.stepSize  = 1;
   this.outputTimeoutSpin.value     = SyQonParallaxParameters.outputTimeoutMinutes;
   this.outputTimeoutSpin.toolTip   = "Maximum time to wait for Parallax output before aborting.";
   this.outputTimeoutSpin.onValueUpdated = function(value) { SyQonParallaxParameters.outputTimeoutMinutes = value; };

   this.outputTimeoutSizer = new HorizontalSizer;
   this.outputTimeoutSizer.spacing = 4;
   this.outputTimeoutSizer.add(this.outputTimeoutLabel);
   this.outputTimeoutSizer.add(this.outputTimeoutSpin);
   this.outputTimeoutSizer.addStretch();

   this.openDialogCheckbox = new CheckBox(this);
   this.openDialogCheckbox.text    = "Open dialog when instance is double-clicked or dropped";
   this.openDialogCheckbox.checked = SyQonParallaxParameters.openDialogBox;
   this.openDialogCheckbox.onCheck = function(checked) { SyQonParallaxParameters.openDialogBox = checked; };

   // ── Executable ──
   this.setupButton = new ToolButton(this);
   this.setupButton.icon = this.scaledResource(":/icons/wrench.png");
   this.setupButton.setScaledFixedSize(24, 24);
   this.setupButton.toolTip = "Select the parallax_cli executable file.";
   this.setupButton.onClick = function() {
      let ofd = new OpenFileDialog;
      ofd.caption            = "Select Parallax Executable";
      ofd.multipleSelections = false;
      if (SyQonParallaxParameters.parallaxExePath.length > 0)
         ofd.initialPath = SyQonParallaxParameters.parallaxExePath;
      if (IS_WINDOWS)
         ofd.filters = [ ["Executable Files", "*.exe"], ["All Files", "*"] ];
      else
         ofd.filters = [ ["All Files", "*"] ];
      if (ofd.execute()) {
         SyQonParallaxParameters.parallaxExePath = ofd.fileName;
         SyQonParallaxParameters.save();
         self.exePathLabel.text = SyQonParallaxParameters.parallaxExePath;
      }
   };

   this.exePathLabel = new TextBox(this);
   this.exePathLabel.readOnly     = true;
   this.exePathLabel.setFixedHeight(48);
   this.exePathLabel.text =
      SyQonParallaxParameters.parallaxExePath.length > 0
         ? SyQonParallaxParameters.parallaxExePath
         : "No Parallax executable selected.";

   this.exePathSizer = new HorizontalSizer;
   this.exePathSizer.spacing = 6;
   this.exePathSizer.add(this.setupButton);
   this.exePathSizer.add(this.exePathLabel, 100);

   // ── Buttons ──
   this.okButton = new PushButton(this);
   this.okButton.text    = "OK";
   this.okButton.onClick = function() { self.syncToParameters(); self.ok(); };

   this.cancelButton = new PushButton(this);
   this.cancelButton.text    = "Cancel";
   this.cancelButton.onClick = function() { self.cancel(); };

   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "Drag to workspace to create a new process instance";
   this.newInstanceButton.onMousePress = function() { self.syncToParameters(); self.newInstance(); };

   this.buttonsSizer = new HorizontalSizer;
   this.buttonsSizer.spacing = 6;
   this.buttonsSizer.add(this.newInstanceButton);
   this.buttonsSizer.addStretch();
   this.buttonsSizer.add(this.okButton);
   this.buttonsSizer.add(this.cancelButton);

   // ── Label width alignment ──
   let labelWidth = this.font.width("Output Timeout (min):MMMM");
   this.imageSelectionLabel.setFixedWidth(labelWidth);
   this.modeLabel.setFixedWidth(labelWidth);
   this.starReductionLabel.setFixedWidth(labelWidth);
   this.sharpenLabel.setFixedWidth(labelWidth);
   this.tileLabel.setFixedWidth(labelWidth);
   this.overlapLabel.setFixedWidth(labelWidth);
   this.padLabel.setFixedWidth(labelWidth);
   this.mtfTargetLabel.setFixedWidth(labelWidth);
   this.outputTimeoutLabel.setFixedWidth(labelWidth);

   // ── GroupBox: Target Image ──
   this.imageGroup       = new GroupBox(this);
   this.imageGroup.title = "Target Image";
   this.imageGroup.sizer = new VerticalSizer;
   this.imageGroup.sizer.margin  = 6;
   this.imageGroup.sizer.spacing = 4;
   this.imageGroup.sizer.add(this.imageSelectionSizer);

   // ── GroupBox: Processing Stages ──
   this.stagesGroup       = new GroupBox(this);
   this.stagesGroup.title = "Processing Stages";
   this.stagesGroup.sizer = new VerticalSizer;
   this.stagesGroup.sizer.margin  = 6;
   this.stagesGroup.sizer.spacing = 4;
   this.stagesGroup.sizer.add(this.modeSizer);
   this.stagesGroup.sizer.add(this.correctAberrationCheckbox);
   this.stagesGroup.sizer.add(this.starReductionSizer);
   this.stagesGroup.sizer.add(this.sharpenSizer);

   // ── GroupBox: Model Settings ──
   this.modelGroup       = new GroupBox(this);
   this.modelGroup.title = "Model Settings";
   this.modelGroup.sizer = new VerticalSizer;
   this.modelGroup.sizer.margin  = 6;
   this.modelGroup.sizer.spacing = 4;
   this.modelGroup.sizer.add(this.tileSizer);
   this.modelGroup.sizer.add(this.overlapSizer);
   this.modelGroup.sizer.add(this.padSizer);

   // ── GroupBox: Stretch ──
   this.stretchGroup       = new GroupBox(this);
   this.stretchGroup.title = "Linear Data Stretch";
   this.stretchGroup.sizer = new VerticalSizer;
   this.stretchGroup.sizer.margin  = 6;
   this.stretchGroup.sizer.spacing = 4;
   this.stretchGroup.sizer.add(this.useMTFCheckbox);
   this.stretchGroup.sizer.add(this.mtfTargetSizer);
   this.stretchGroup.sizer.add(this.linkedStretchCheckbox);

   // ── GroupBox: Performance ──
   this.performanceGroup       = new GroupBox(this);
   this.performanceGroup.title = "Performance";
   this.performanceGroup.sizer = new VerticalSizer;
   this.performanceGroup.sizer.margin  = 6;
   this.performanceGroup.sizer.spacing = 4;
   this.performanceGroup.sizer.add(this.useCPUCheckbox);
   this.performanceGroup.sizer.add(this.noDMLCheckbox);

   // ── GroupBox: Advanced ──
   this.advancedGroup       = new GroupBox(this);
   this.advancedGroup.title = "Advanced";
   this.advancedGroup.sizer = new VerticalSizer;
   this.advancedGroup.sizer.margin  = 6;
   this.advancedGroup.sizer.spacing = 4;
   this.advancedGroup.sizer.add(this.outputTimeoutSizer);
   this.advancedGroup.sizer.add(this.openDialogCheckbox);

   // ── GroupBox: Executable ──
   this.executableGroup       = new GroupBox(this);
   this.executableGroup.title = "Parallax Executable";
   this.executableGroup.sizer = new VerticalSizer;
   this.executableGroup.sizer.margin  = 6;
   this.executableGroup.sizer.spacing = 4;
   this.executableGroup.sizer.add(this.exePathSizer);

   // ── Copyright footer ──
   this.copyrightLabel = new Label(this);
   this.copyrightLabel.useRichText   = true;
   this.copyrightLabel.textAlignment = TextAlign_Center;
   this.copyrightLabel.text =
      "<font size='-1'>\u00A9 SyQon 2026 \u2014 www.syqon.it</font>";

   // ── Main layout ──
   this.sizer = new VerticalSizer;
   this.sizer.margin  = 12;
   this.sizer.spacing = 8;
   this.sizer.add(this.headerLabel);
   this.sizer.add(this.headerSeparator);
   this.sizer.addSpacing(4);
   this.sizer.add(this.imageGroup);
   this.sizer.add(this.stagesGroup);
   this.sizer.add(this.modelGroup);
   this.sizer.add(this.stretchGroup);
   this.sizer.add(this.performanceGroup);
   this.sizer.add(this.advancedGroup);
   this.sizer.add(this.executableGroup);
   this.sizer.addSpacing(8);
   this.sizer.add(this.buttonsSizer);
   this.sizer.addSpacing(2);
   this.sizer.add(this.copyrightLabel);

   this.windowTitle = "SyQon Parallax " + VERSION;
   this.setMinWidth(560);
   this.adjustToContents();

   if (SyQonParallaxParameters.targetViewId && SyQonParallaxParameters.targetViewId.length > 0)
      this.selectViewById(SyQonParallaxParameters.targetViewId);
}
SyQonParallaxDialog.prototype = new Dialog;

// ----------------------------------------------------------------------------
// Main
// ----------------------------------------------------------------------------

function main() {
   console.show();
   Console.criticalln(" ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗");
   Console.criticalln(" ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║");
   Console.criticalln(" ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║");
   Console.warningln(" ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║");
   Console.warningln(" ███████║   ██║   ╚██████╔╝╚█████╔╝ ██║ ╚████║");
   Console.warningln(" ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝");
   Console.noteln("Starting SyQon \u2605 P A R A L L A X \u2605  " + VERSION);
   Console.noteln("\u00A9 SyQon 2026 \u2014 www.syqon.it");
   console.flush();

   SyQonParallaxParameters.load();

   if (Parameters.isGlobalTarget) {
      Console.criticalln("This script cannot run in a global context.");
      return;
   }

   if (Parameters.isViewTarget && Parameters.targetView) {
      SyQonParallaxParameters.targetView   = Parameters.targetView;
      SyQonParallaxParameters.targetViewId = Parameters.targetView.id;
      SyQonParallaxParameters.save();

      if (SyQonParallaxParameters.openDialogBox) {
         let dlg = new SyQonParallaxDialog();
         dlg.selectViewById(SyQonParallaxParameters.targetViewId);
         if (dlg.execute()) {
            let selectedWindow = getSelectedWindowFromDialog(dlg);
            if (!selectedWindow)
               selectedWindow = resolveWindowFromViewId(SyQonParallaxParameters.targetViewId);
            executeParallaxOnWindow(selectedWindow);
         } else {
            Console.noteln("SyQon Parallax dialog closed.");
         }
         return;
      }

      executeParallaxOnWindow(Parameters.targetView.window);
      return;
   }

   let dlg = new SyQonParallaxDialog();
   if (dlg.execute()) {
      let selectedWindow = getSelectedWindowFromDialog(dlg);
      if (!selectedWindow && SyQonParallaxParameters.targetViewId.length > 0)
         selectedWindow = resolveWindowFromViewId(SyQonParallaxParameters.targetViewId);
      if (!selectedWindow)
         throw new Error("Please select an image.");
      executeParallaxOnWindow(selectedWindow);
   } else {
      Console.noteln("SyQon Parallax dialog closed.");
   }
}

main();
