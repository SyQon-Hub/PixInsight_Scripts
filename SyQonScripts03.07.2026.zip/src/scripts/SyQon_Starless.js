#feature-id SyQonStarless : SyQon > Starless
#feature-icon  syqonstarless.svg
#feature-info This script integrates with the SyQon Starless CLI application to remove stars from images.

/****************************************************************************
 * ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗
 * ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║
 * ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║
 * ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║
 * ███████║   ██║   ╚██████╔╝╚█████╔╝██║ ╚████║
 * ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝
 *      ★  S T A R L E S S  ★
 *
 * SyQon Starless CLI PixInsight Integration
 * Version: v1.0
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script integrates with the SyQon Starless CLI application.
 * It saves the current image as a temporary FITS file, runs Starless
 * headlessly with the selected options, and then imports the starless
 * result back into the target image.
 *
 * CLI options used:
 *   --input
 *   --output
 *   --tile
 *   --overlap
 *   --temp-stretch
 *   --backend
 *
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>

#define VERSION "v1.0"

// ----------------------------------------------------------------------------
// Platform helpers
// ----------------------------------------------------------------------------

let IS_WINDOWS = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows");
let IS_MACOS   = (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS");
let IS_LINUX   = (CoreApplication.platform == "Linux");

if (!IS_WINDOWS && !IS_MACOS && !IS_LINUX)
   console.criticalln("Unsupported platform: " + CoreApplication.platform);

let pathSeparator = IS_WINDOWS ? "\\" : "/";

// ----------------------------------------------------------------------------
// Temp/config paths
// ----------------------------------------------------------------------------

let scriptTempDir = File.systemTempDirectory + pathSeparator + "SyQonStarlessCLI";
let syqonStarlessConfigFile = scriptTempDir + pathSeparator + "syqon_starless_config.csv";

if (!File.directoryExists(scriptTempDir))
   File.createDirectory(scriptTempDir);

// ----------------------------------------------------------------------------
// Parameters
// ----------------------------------------------------------------------------

var SyQonStarlessParameters = {
   targetView: undefined,
   starlessExePath: "",
   tileSize: 512,
   overlap: 96,
   tempStretch: true,
   backend: "Auto",
   starsOnlyMode: "Unscreen", // None, Subtraction, Unscreen

   save: function() {
      Parameters.set("starlessExePath", this.starlessExePath);
      Parameters.set("tileSize", this.tileSize);
      Parameters.set("overlap", this.overlap);
      Parameters.set("tempStretch", this.tempStretch);
      Parameters.set("backend", this.backend);
      Parameters.set("starsOnlyMode", this.starsOnlyMode);
      this.savePathToFile();
   },

   load: function() {
      if (Parameters.has("starlessExePath"))
         this.starlessExePath = Parameters.getString("starlessExePath");
      if (Parameters.has("tileSize"))
         this.tileSize = Parameters.getInteger("tileSize");
      if (Parameters.has("overlap"))
         this.overlap = Parameters.getInteger("overlap");
      if (Parameters.has("tempStretch"))
         this.tempStretch = Parameters.getBoolean("tempStretch");
      if (Parameters.has("backend"))
         this.backend = Parameters.getString("backend");
      if (Parameters.has("starsOnlyMode"))
         this.starsOnlyMode = Parameters.getString("starsOnlyMode");
      this.loadPathFromFile();
   },

   savePathToFile: function() {
      try {
         let file = new File;
         file.createForWriting(syqonStarlessConfigFile);
         file.outTextLn(this.starlessExePath);
         file.close();
      } catch (error) {
         console.warningln("Failed to save Starless executable path: " + error.message);
      }
   },

   loadPathFromFile: function() {
      try {
         if (File.exists(syqonStarlessConfigFile)) {
            let lines = File.readLines(syqonStarlessConfigFile);
            if (lines.length > 0)
               this.starlessExePath = lines[0].trim();
         }
      } catch (error) {
         console.warningln("Failed to load Starless executable path: " + error.message);
      }
   }
};

// ----------------------------------------------------------------------------
// Utility helpers
// ----------------------------------------------------------------------------

function sanitizeFileName(name) {
   return name.replace(/[^A-Za-z0-9_\-]/g, "_");
}

function deleteFileIfExists(filePath) {
   try {
      if (File.exists(filePath)) {
         File.remove(filePath);
         console.writeln("Deleted file: " + filePath);
      }
   } catch (error) {
      console.warningln("Failed to delete file: " + filePath + " -> " + error.message);
   }
}

function waitForFile(filePath, timeoutMs) {
   let start = (new Date()).getTime();
   let pollingInterval = 500;

   while (((new Date()).getTime() - start) < timeoutMs) {
      if (File.exists(filePath)) {
         console.writeln("Output file found: " + filePath);
         msleep(1000); // extra settle time
         return true;
      }
      processEvents();
      msleep(pollingInterval);
   }

   return false;
}

function getActiveWindowIdSafe() {
   try {
      return ImageWindow.activeWindow.mainView.id;
   } catch (e) {
      return "";
   }
}

function ensureTempDirExists() {
   if (!File.directoryExists(scriptTempDir))
      File.createDirectory(scriptTempDir);
}

function buildRunPaths(baseName) {
   ensureTempDirExists();

   let runTag = String((new Date()).getTime());
   let safeBase = sanitizeFileName(baseName);

   return {
      inputFilePath:  scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_input.fits",
      outputFilePath: scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_starless.fits"
   };
}

// ----------------------------------------------------------------------------
// Executable resolution
// ----------------------------------------------------------------------------

function validateStarlessExecutable(exePath) {
   if (!exePath || exePath.length == 0)
      return false;
   return File.exists(exePath);
}

// ----------------------------------------------------------------------------
// FITS save/load
// ----------------------------------------------------------------------------

function saveImageAsFits(filePath, view) {
   let imgWindow = view.isMainView ? view.window : view.mainView.window;
   if (!imgWindow)
      throw new Error("Image window is undefined for the specified view.");

   if (!imgWindow.saveAs(filePath, false, false, false, false))
      throw new Error("Failed to save image as FITS: " + filePath);

   console.writeln("Image saved as FITS: " + filePath);
   return filePath;
}

function starlessReferenceExpression(targetView, starlessWindow) {
   if (!targetView.image.isColor && starlessWindow.mainView.image.isColor)
      return starlessWindow.mainView.id + "[0]";
   return starlessWindow.mainView.id;
}

function openStarlessOutput(outputFilePath) {
   if (!File.exists(outputFilePath))
      throw new Error("Starless output file not found: " + outputFilePath);

   let opened = ImageWindow.open(outputFilePath);
   if (!opened || opened.length < 1)
      throw new Error("Failed to open Starless output image: " + outputFilePath);

   let outWindow = opened[0];
   outWindow.show();
   return outWindow;
}

function createStarsOnlyImage(originalWindow, starlessWindow, mode) {
   if (mode == "None")
      return;

   let originalId = originalWindow.mainView.id;
   let starlessExpr = starlessReferenceExpression(originalWindow.mainView, starlessWindow);

   let pm = new PixelMath;
   pm.useSingleExpression = true;
   pm.createNewImage = true;
   pm.rescale = false;
   pm.truncate = false;
   pm.newImageId = originalId + "_StarsOnly";
   pm.newImageWidth = originalWindow.mainView.image.width;
   pm.newImageHeight = originalWindow.mainView.image.height;
   pm.newImageAlpha = false;
   pm.newImageColorSpace = originalWindow.mainView.image.isColor ? PixelMath.prototype.RGB : PixelMath.prototype.Gray;
   pm.newImageSampleFormat = PixelMath.prototype.f32;

   if (mode == "Subtraction") {
      pm.expression = originalId + " - " + starlessExpr;
   } else {
      pm.expression =
         "iif(abs(1 - " + starlessExpr + ") < 1.0e-6, 0, (" +
         originalId + " - " + starlessExpr + ")/(1 - " + starlessExpr + "))";
   }

   pm.executeGlobal();
}

function overwriteTargetWithStarless(targetWindow, starlessWindow) {
   let targetView = targetWindow.mainView;
   let expr = starlessReferenceExpression(targetView, starlessWindow);

   let pm = new PixelMath;
   pm.useSingleExpression = true;
   pm.createNewImage = false;
   pm.rescale = false;
   pm.truncate = false;
   pm.expression = expr;
   pm.executeOn(targetView);
}

function processStarlessOutput(outputFilePath, targetWindow, starsOnlyMode) {
   let starlessWindow = openStarlessOutput(outputFilePath);

   // Create stars-only first, while both original and imported starless are available
   if (starsOnlyMode != "None")
      createStarsOnlyImage(targetWindow, starlessWindow, starsOnlyMode);

   // Then overwrite target so the target keeps its original ID/name
   overwriteTargetWithStarless(targetWindow, starlessWindow);

   starlessWindow.forceClose();
   deleteFileIfExists(outputFilePath);
}
// ----------------------------------------------------------------------------
// CLI argument construction
// ----------------------------------------------------------------------------

function buildStarlessArgs(inputFilePath, outputFilePath, tileSize, overlap, tempStretch, backend) {
   let args = [];

   args.push("--input");
   args.push(inputFilePath);

   args.push("--output");
   args.push(outputFilePath);

   args.push("--tile");
   args.push(String(tileSize));

   args.push("--overlap");
   args.push(String(overlap));

   if (tempStretch)
      args.push("--temp-stretch");

   if (backend && backend.length > 0) {
      args.push("--backend");
      args.push(backend);
   }

   return args;
}

// ----------------------------------------------------------------------------
// External process runner
// ----------------------------------------------------------------------------

function runStarlessProcess(exePath, args, expectedOutputFilePath) {
   let process = new ExternalProcess;
   let lastProgress = "";

   process.onStandardOutputDataAvailable = function() {
      let output = String(this.stdout);
      if (!output || output.length == 0)
         return;

      // Parse simple CLI progress like: [ 45%] 12/27
      let match = output.match(/\[\s*(\d+)%\]\s+(\d+)\/(\d+)/);
      if (match) {
         let percentage = parseInt(match[1], 10);
         let processed  = parseInt(match[2], 10);
         let total      = parseInt(match[3], 10);

         let newProgress = format("Progress: %3d%% (%4d/%4d tiles)", percentage, processed, total);

         let backspaces = "";
         for (let i = 0; i < lastProgress.length; i++)
            backspaces += "\b";

         Console.write(backspaces + newProgress);
         lastProgress = newProgress;
      } else {
         if (lastProgress.length > 0) {
            Console.writeln("");
            lastProgress = "";
         }
         Console.writeln(output.trim());
      }
   };

   process.onStandardErrorDataAvailable = function() {
      let err = this.stderr.toString();
      if (err && err.length > 0)
         Console.warningln(err.trim());
   };

   process.onStarted = function() {
      Console.noteln("Starting Starless CLI...");
      Console.noteln("Executable: " + exePath);
      Console.noteln("Arguments: " + args.join(" "));
   };

   process.onFinished = function() {
      if (lastProgress.length > 0) {
         Console.writeln("");
         lastProgress = "";
      }
      Console.noteln("Starless CLI finished.");
   };

   process.onError = function(code) {
      // Do NOT treat this as fatal here.
      // PixInsight can report bogus startup/process errors even when the app actually runs.
      Console.warningln("ExternalProcess reported: " + code + " (ignored, waiting for output file)");
   };

   // IMPORTANT:
   // We intentionally do NOT trust the return value of process.start() here.
   // PixInsight may report failure even when the external executable launches correctly.
   try {
      process.start(exePath, args);
   } catch (e) {
      Console.warningln("process.start reported an exception: " + e.message + " (ignored, waiting for output file)");
   }

   // Give the process subsystem a moment, but do not rely on these states.
   try {
      let spinStart = (new Date()).getTime();
      while (process.isStarting && ((new Date()).getTime() - spinStart) < 5000)
         processEvents();
   } catch (e) {
   }

   try {
      let runStart = (new Date()).getTime();
      while (process.isRunning && ((new Date()).getTime() - runStart) < 5000)
         processEvents();
   } catch (e) {
   }

   // REAL success/failure test:
   // if the output file appears within timeout, we consider the run successful.
   if (!waitForFile(expectedOutputFilePath, 1200000))
      throw new Error("Starless output file was not found before timeout.");
}

// ----------------------------------------------------------------------------
// Dialog
// ----------------------------------------------------------------------------

function SyQonStarlessDialog() {
   this.__base__ = Dialog;
   this.__base__();

   console.hide();
   SyQonStarlessParameters.load();

   this.title = new Label(this);
   this.title.text = "SyQon Starless CLI v1.0";
   this.title.textAlignment = TextAlign_Center;

   this.description = new TextBox(this);
   this.description.readOnly = true;
   this.description.text =
      "This script integrates with the SyQon Starless CLI application.\n\n" +
      "Use the wrench button to select the Starless executable file itself " +
      "(for example, Starless.exe or Starless-CUDA.exe on Windows).\n\n" +
      "The script saves the selected image as a temporary FITS file, runs Starless headlessly, " +
      "imports the starless result as a temporary image, optionally creates a Stars Only image, " +
      "and then uses PixelMath to overwrite the current target view so the original view name remains unchanged.\n\n" +
      "Options exposed here map directly to the CLI: tile size, overlap, temp stretch, and backend.";
   this.description.setMinWidth(450);
   this.description.setMinHeight(240);

   // Image selection
   this.imageSelectionLabel = new Label(this);
   this.imageSelectionLabel.text = "Select Image:";
   this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.imageSelectionDropdown = new ComboBox(this);
   this.imageSelectionDropdown.editEnabled = false;

   let windows = ImageWindow.windows;
   let activeWindowId = getActiveWindowIdSafe();

   for (let i = 0; i < windows.length; ++i) {
      this.imageSelectionDropdown.addItem(windows[i].mainView.id);
      if (windows[i].mainView.id == activeWindowId)
         this.imageSelectionDropdown.currentItem = i;
   }

   this.imageSelectionSizer = new HorizontalSizer;
   this.imageSelectionSizer.spacing = 4;
   this.imageSelectionSizer.add(this.imageSelectionLabel);
   this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

   // Tile size
   this.tileLabel = new Label(this);
   this.tileLabel.text = "Tile Size:";
   this.tileLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.tileSpin = new SpinBox(this);
   this.tileSpin.minValue = 128;
   this.tileSpin.maxValue = 2048;
   this.tileSpin.stepSize = 64;
   this.tileSpin.value = SyQonStarlessParameters.tileSize;
   this.tileSpin.onValueUpdated = function(value) {
      SyQonStarlessParameters.tileSize = value;
   };

   this.tileSizer = new HorizontalSizer;
   this.tileSizer.spacing = 4;
   this.tileSizer.add(this.tileLabel);
   this.tileSizer.add(this.tileSpin);
   this.tileSizer.addStretch();

   // Overlap
   this.overlapLabel = new Label(this);
   this.overlapLabel.text = "Overlap:";
   this.overlapLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.overlapSpin = new SpinBox(this);
   this.overlapSpin.minValue = 8;
   this.overlapSpin.maxValue = 512;
   this.overlapSpin.stepSize = 8;
   this.overlapSpin.value = SyQonStarlessParameters.overlap;
   this.overlapSpin.onValueUpdated = function(value) {
      SyQonStarlessParameters.overlap = value;
   };

   this.overlapSizer = new HorizontalSizer;
   this.overlapSizer.spacing = 4;
   this.overlapSizer.add(this.overlapLabel);
   this.overlapSizer.add(this.overlapSpin);
   this.overlapSizer.addStretch();

   // Temp stretch
   this.tempStretchCheckbox = new CheckBox(this);
   this.tempStretchCheckbox.text = "Use Temp Stretch";
   this.tempStretchCheckbox.checked = SyQonStarlessParameters.tempStretch;
   this.tempStretchCheckbox.toolTip = "Uses Starless temp stretch / destretch pipeline (recommended for linear data).";
   this.tempStretchCheckbox.onCheck = function(checked) {
      SyQonStarlessParameters.tempStretch = checked;
   };

   // Backend
   this.backendLabel = new Label(this);
   this.backendLabel.text = "Backend:";
   this.backendLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.backendCombo = new ComboBox(this);
   this.backendCombo.addItem("Auto");
   this.backendCombo.addItem("CUDA");
   this.backendCombo.addItem("DirectML");
   this.backendCombo.addItem("MPS");
   this.backendCombo.addItem("CPU");

   let backendIndex = 0;
   for (let i = 0; i < this.backendCombo.numberOfItems; ++i) {
      if (this.backendCombo.itemText(i) == SyQonStarlessParameters.backend) {
         backendIndex = i;
         break;
      }
   }
   this.backendCombo.currentItem = backendIndex;
   this.backendCombo.onItemSelected = function(index) {
      SyQonStarlessParameters.backend = this.itemText(index);
   };

   this.backendSizer = new HorizontalSizer;
   this.backendSizer.spacing = 4;
   this.backendSizer.add(this.backendLabel);
   this.backendSizer.add(this.backendCombo, 100);

   this.starsOnlyModeLabel = new Label(this);
   this.starsOnlyModeLabel.text = "Stars Only:";
   this.starsOnlyModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.starsOnlyModeCombo = new ComboBox(this);
   this.starsOnlyModeCombo.addItem("None");
   this.starsOnlyModeCombo.addItem("Subtraction");
   this.starsOnlyModeCombo.addItem("Unscreen");

   let somIndex = 2;
   if (SyQonStarlessParameters.starsOnlyMode == "Subtraction")
      somIndex = 1;
   else if (SyQonStarlessParameters.starsOnlyMode == "Unscreen")
      somIndex = 2;

   this.starsOnlyModeCombo.currentItem = somIndex;

   // Force the backing parameter to match the visible default selection
   SyQonStarlessParameters.starsOnlyMode = this.starsOnlyModeCombo.itemText(this.starsOnlyModeCombo.currentItem);

   this.starsOnlyModeCombo.onItemSelected = function(index) {
      SyQonStarlessParameters.starsOnlyMode = this.itemText(index);
   };

   this.starsOnlyModeSizer = new HorizontalSizer;
   this.starsOnlyModeSizer.spacing = 4;
   this.starsOnlyModeSizer.add(this.starsOnlyModeLabel);
   this.starsOnlyModeSizer.add(this.starsOnlyModeCombo, 100);

   // Setup button
   this.setupButton = new ToolButton(this);
   this.setupButton.icon = this.scaledResource(":/icons/wrench.png");
   this.setupButton.setScaledFixedSize(24, 24);
   this.setupButton.toolTip = "Select the Starless executable file.";
   this.setupButton.onClick = function() {
      let ofd = new OpenFileDialog;
      ofd.caption = "Select Starless Executable";
      if (SyQonStarlessParameters.starlessExePath.length > 0)
         ofd.initialPath = SyQonStarlessParameters.starlessExePath;
      ofd.multipleSelections = false;

      if (IS_WINDOWS)
         ofd.filters = [ ["Executable Files", "*.exe"], ["All Files", "*"] ];
      else
         ofd.filters = [ ["All Files", "*"] ];

      if (ofd.execute()) {
         SyQonStarlessParameters.starlessExePath = ofd.fileName;
         SyQonStarlessParameters.save();
         this.dialog.exePathLabel.text = SyQonStarlessParameters.starlessExePath;
      }
   };

   this.exePathLabel = new TextBox(this);
   this.exePathLabel.readOnly = true;
   this.exePathLabel.setMinWidth(450);
   this.exePathLabel.setFixedHeight(50);
   this.exePathLabel.text =
      SyQonStarlessParameters.starlessExePath.length > 0
         ? SyQonStarlessParameters.starlessExePath
         : "No Starless executable selected.";
   // Buttons
   this.okButton = new PushButton(this);
   this.okButton.text = "OK";
   this.okButton.onClick = function() { this.dialog.ok(); };

   this.cancelButton = new PushButton(this);
   this.cancelButton.text = "Cancel";
   this.cancelButton.onClick = function() { this.dialog.cancel(); };

   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "Save a new instance of this script";
   this.newInstanceButton.onMousePress = function() {
      this.dialog.newInstance();
   };

   this.buttonsSizer = new HorizontalSizer;
   this.buttonsSizer.spacing = 6;
   this.buttonsSizer.add(this.newInstanceButton);
   this.buttonsSizer.addStretch();
   this.buttonsSizer.add(this.okButton);
   this.buttonsSizer.add(this.cancelButton);
   this.buttonsSizer.addStretch();

   // Layout
   this.sizer = new VerticalSizer;
   this.sizer.margin = 6;
   this.sizer.spacing = 6;
   this.sizer.addStretch();
   this.sizer.add(this.title);
   this.sizer.add(this.description);
   this.sizer.addSpacing(8);
   this.sizer.add(this.imageSelectionSizer);
   this.sizer.add(this.tileSizer);
   this.sizer.add(this.overlapSizer);
   this.sizer.add(this.tempStretchCheckbox);
   this.sizer.add(this.backendSizer);
   this.sizer.add(this.starsOnlyModeSizer);
   this.sizer.add(this.setupButton);
   this.sizer.add(this.exePathLabel);
   this.sizer.addSpacing(12);
   this.sizer.add(this.buttonsSizer);

   this.windowTitle = "SyQon Starless CLI";
   this.adjustToContents();
}
SyQonStarlessDialog.prototype = new Dialog;

// ----------------------------------------------------------------------------
// Main
// ----------------------------------------------------------------------------

let dialog = new SyQonStarlessDialog();

console.show();
Console.criticalln(" ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗");
Console.criticalln(" ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║");
Console.criticalln(" ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║");
Console.warningln(" ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║");
Console.warningln(" ███████║   ██║   ╚██████╔╝╚█████╔╝ ██║ ╚████║");
Console.warningln(" ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝");
Console.noteln    ("Starting SyQon ★ S T A R L E S S ★  " + VERSION);
console.flush();

if (dialog.execute()) {
   let tempInputFilePath = "";
   let tempOutputFilePath = "";

   try {
      SyQonStarlessParameters.save();

      if (SyQonStarlessParameters.overlap >= SyQonStarlessParameters.tileSize)
         throw new Error("Overlap must be smaller than tile size.");

      if (SyQonStarlessParameters.starlessExePath.length == 0)
         throw new Error("Please select the Starless executable with the wrench button.");

      if (!validateStarlessExecutable(SyQonStarlessParameters.starlessExePath))
         throw new Error("Selected Starless executable does not exist.");

      let selectedIndex = dialog.imageSelectionDropdown.currentItem;
      let selectedWindow = ImageWindow.windows[selectedIndex];
      if (!selectedWindow)
         throw new Error("Please select an image.");

      let baseName = selectedWindow.mainView.id;
      let runPaths = buildRunPaths(baseName);

      tempInputFilePath = runPaths.inputFilePath;
      tempOutputFilePath = runPaths.outputFilePath;

      saveImageAsFits(tempInputFilePath, selectedWindow);

      let args = buildStarlessArgs(
         tempInputFilePath,
         tempOutputFilePath,
         SyQonStarlessParameters.tileSize,
         SyQonStarlessParameters.overlap,
         SyQonStarlessParameters.tempStretch,
         SyQonStarlessParameters.backend
      );

      let exePath = SyQonStarlessParameters.starlessExePath;

      runStarlessProcess(exePath, args, tempOutputFilePath);
      processStarlessOutput(
         tempOutputFilePath,
         selectedWindow,
         SyQonStarlessParameters.starsOnlyMode
      );

      console.writeln("Starless processing complete.");
   } catch (error) {
      console.criticalln("SyQon Starless CLI failed: " + error.message);
   } finally {
      if (tempInputFilePath.length > 0)
         deleteFileIfExists(tempInputFilePath);

      // Optional safety cleanup in case processing failed before the output
      // temp file was opened/consumed and deleted.
      if (tempOutputFilePath.length > 0)
         deleteFileIfExists(tempOutputFilePath);
   }
}
